using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EntityCore.Data.Entities
{
    public partial class BuywiseContext : DbContext
    {
        public BuywiseContext(DbContextOptions<BuywiseContext> options)
            : base(options)
        {
        }

        #region Generated Properties
        public virtual DbSet<EntityCore.Data.Entities.AspNetRoleClaims> AspNetRoleClaims { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetRoles> AspNetRoles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetUserClaims> AspNetUserClaims { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetUserLogins> AspNetUserLogins { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetUserRoles> AspNetUserRoles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetUsers> AspNetUsers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AspNetUserTokens> AspNetUserTokens { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAdditionalFiles> AssessmentAdditionalFiles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAuditDCategories> AssessmentAuditDCategories { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAuditD> AssessmentAuditDs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAuditECategories> AssessmentAuditECategories { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAuditE> AssessmentAuditEs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentAuditFiles> AssessmentAuditFiles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementAboveFoundationType> AssessmentBasementAboveFoundationTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementComposite> AssessmentBasementComposites { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementConstruction> AssessmentBasementConstructions { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementInsulationSlab> AssessmentBasementInsulationSlabs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementInsulationSlabType> AssessmentBasementInsulationSlabTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementInteriorInsulationType> AssessmentBasementInteriorInsulationTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasementPonyType> AssessmentBasementPonyTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentBasement> AssessmentBasements { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCeilingInfo> AssessmentCeilingInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCeilingType> AssessmentCeilingTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentComponent> AssessmentComponents { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentConstruction> AssessmentConstructions { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCrawlspaceAboveFoundationType> AssessmentCrawlspaceAboveFoundationTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCrawlSpaceComposite> AssessmentCrawlSpaceComposites { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCrawlSpaceConstruction> AssessmentCrawlSpaceConstructions { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCrawlSpace> AssessmentCrawlSpaces { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentCrawlspaceWallType> AssessmentCrawlspaceWallTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDHWManufacturer> AssessmentDHWManufacturers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDHWModel> AssessmentDHWModels { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDHW> AssessmentDHWs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDoorInfo> AssessmentDoorInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDoorType> AssessmentDoorTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDuplicateFollowup> AssessmentDuplicateFollowups { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentDuplicateNodes> AssessmentDuplicateNodes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentEnerGuideAtypical> AssessmentEnerGuideAtypicals { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentEnerGuideHouseHold> AssessmentEnerGuideHouseHolds { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentEnerGuideReducedOperating> AssessmentEnerGuideReducedOperatings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentEnerGuideRUR> AssessmentEnerGuideRURs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentEnerGuide> AssessmentEnerGuides { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentFacingDirection> AssessmentFacingDirections { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentFloorHeaderInfo> AssessmentFloorHeaderInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentFloorHeaderType> AssessmentFloorHeaderTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentFloorInfo> AssessmentFloorInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentFloorType> AssessmentFloorTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentGeneralFiles> AssessmentGeneralFiles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentGenerationInfo> AssessmentGenerationInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentGenerationPhotoVoltaic> AssessmentGenerationPhotoVoltaics { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolAdditionalOpenings> AssessmentHeatCoolAdditionalOpenings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolCSADetails> AssessmentHeatCoolCSADetails { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolCSAManufacturer> AssessmentHeatCoolCSAManufacturers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolCSAModel> AssessmentHeatCoolCSAModels { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolCSA> AssessmentHeatCoolCSAs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolRadiant> AssessmentHeatCoolRadiants { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolSupplyHtg> AssessmentHeatCoolSupplyHtgs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolTypeOne> AssessmentHeatCoolTypeOnes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatCoolTypeTwo> AssessmentHeatCoolTypeTwos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHeatingCooling> AssessmentHeatingCoolings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentHouseType> AssessmentHouseTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentInfo> AssessmentInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentInsulationLayerOne> AssessmentInsulationLayerOnes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentInsulationLayerTwo> AssessmentInsulationLayerTwos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentLocalShielding> AssessmentLocalShieldings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentLocation> AssessmentLocations { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalAirLeakage> AssessmentNaturalAirLeakages { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalSpecAirTightness> AssessmentNaturalSpecAirTightnesses { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalSpec> AssessmentNaturalSpecs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalSpecTerrain> AssessmentNaturalSpecTerrains { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalTestEquipItems> AssessmentNaturalTestEquipItems { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentNaturalTestEquip> AssessmentNaturalTestEquips { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentOrientations> AssessmentOrientations { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentOtherFiles> AssessmentOtherFiles { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentPaperAttachment> AssessmentPaperAttachments { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentPlanUpgrades> AssessmentPlanUpgrades { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentRegion> AssessmentRegions { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentReport> AssessmentReports { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentRequest> AssessmentRequests { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Assessment> Assessments { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentSketch> AssessmentSketches { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentSlabGradeConstruction> AssessmentSlabGradeConstructions { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentSlabGrade> AssessmentSlabGrades { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentSpecifications> AssessmentSpecifications { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentStoreys> AssessmentStoreys { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentTemperatureInfo> AssessmentTemperatureInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentTilt> AssessmentTilts { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentUser> AssessmentUsers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentValidationMessage> AssessmentValidationMessages { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentVentilation> AssessmentVentilations { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentVentilationTypes> AssessmentVentilationTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWallColour> AssessmentWallColours { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWallInfo> AssessmentWallInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWallType> AssessmentWallTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWeather> AssessmentWeathers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWindowInfo> AssessmentWindowInfos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentWindowType> AssessmentWindowTypes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.AssessmentYearBuilt> AssessmentYearBuilts { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingAboutUs> BookingAboutUs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingAboutUsValue> BookingAboutUsValues { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingAdditionalDetail> BookingAdditionalDetails { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingAgreement> BookingAgreements { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingAgreementValue> BookingAgreementValues { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingEventSeries> BookingEventSeries { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.BookingSchedularNotes> BookingSchedularNotes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ClientOwners> ClientOwners { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ClientProperty> ClientProperties { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Client> Clients { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Company> Companies { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ComponentChilds> ComponentChilds { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Component> Components { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ElevationTypeOne> ElevationTypeOnes { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ElevationTypeTwo> ElevationTypeTwos { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.EmailTrackingBounced> EmailTrackingBounceds { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.EmailTracking> EmailTrackings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.EnerGuideRurComments> EnerGuideRurComments { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.ErrorLogs> ErrorLogs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.FinancialTracking> FinancialTrackings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.HistoryLogs> HistoryLogs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.IncentivesAuditD> IncentivesAuditDs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.IncentivesAuditE> IncentivesAuditEs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Logs> Logs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.MessageCenterAttachments> MessageCenterAttachments { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.MessageCenter> MessageCenters { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.MessageCenterUserAcknowledgement> MessageCenterUserAcknowledgements { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Notifications> Notifications { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.OrgAdditionalSettings> OrgAdditionalSettings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.OrganisationSettings> OrganisationSettings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.OrgWeeklyAvailability> OrgWeeklyAvailabilities { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Owners> Owners { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Ownership> Ownerships { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.PlanUpgrades> PlanUpgrades { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Property> Properties { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Province> Provinces { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.QaAssessmentDetail> QaAssessmentDetails { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.QaAssessmentRecord> QaAssessmentRecords { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.QaCompanySetting> QaCompanySettings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.QaUserSetting> QaUserSettings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.RegulatoryDocument> RegulatoryDocuments { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.TempCustomers> TempCustomers { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.TempEAs> TempEAs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.TempJobs> TempJobs { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.TempJobsLatestUpdated> TempJobsLatestUpdateds { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserAdditionalSettings> UserAdditionalSettings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserBooking> UserBookings { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserClaimStatus> UserClaimStatuses { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserClient> UserClients { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserDetail> UserDetails { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserProperty> UserProperties { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.Users> Users { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserWeeklyAvailability> UserWeeklyAvailabilities { get; set; }

        public virtual DbSet<EntityCore.Data.Entities.UserWeeklySchedule> UserWeeklySchedules { get; set; }

        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region Generated Configuration
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetRoleClaimsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetRolesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetUserClaimsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetUserLoginsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetUserRolesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetUsersMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AspNetUserTokensMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAdditionalFilesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAuditDCategoriesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAuditDMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAuditECategoriesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAuditEMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentAuditFilesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementAboveFoundationTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementCompositeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementConstructionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementInsulationSlabMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementInsulationSlabTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementInteriorInsulationTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentBasementPonyTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCeilingInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCeilingTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentComponentMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentConstructionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCrawlspaceAboveFoundationTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCrawlSpaceCompositeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCrawlSpaceConstructionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCrawlSpaceMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentCrawlspaceWallTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDHWManufacturerMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDHWMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDHWModelMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDoorInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDoorTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDuplicateFollowupMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentDuplicateNodesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentEnerGuideAtypicalMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentEnerGuideHouseHoldMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentEnerGuideMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentEnerGuideReducedOperatingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentEnerGuideRURMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentFacingDirectionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentFloorHeaderInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentFloorHeaderTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentFloorInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentFloorTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentGeneralFilesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentGenerationInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentGenerationPhotoVoltaicMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolAdditionalOpeningsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolCSADetailsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolCSAManufacturerMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolCSAMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolCSAModelMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolRadiantMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolSupplyHtgMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolTypeOneMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatCoolTypeTwoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHeatingCoolingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentHouseTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentInsulationLayerOneMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentInsulationLayerTwoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentLocalShieldingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentLocationMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalAirLeakageMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalSpecAirTightnessMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalSpecMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalSpecTerrainMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalTestEquipItemsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentNaturalTestEquipMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentOrientationsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentOtherFilesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentPaperAttachmentMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentPlanUpgradesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentRegionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentReportMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentRequestMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentSketchMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentSlabGradeConstructionMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentSlabGradeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentSpecificationsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentStoreysMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentTemperatureInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentTiltMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentUserMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentValidationMessageMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentVentilationMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentVentilationTypesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWallColourMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWallInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWallTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWeatherMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWindowInfoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentWindowTypeMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.AssessmentYearBuiltMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingAboutUsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingAboutUsValueMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingAdditionalDetailMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingAgreementMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingAgreementValueMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingEventSeriesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.BookingSchedularNotesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ClientMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ClientOwnersMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ClientPropertyMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.CompanyMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ComponentChildsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ComponentMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ElevationTypeOneMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ElevationTypeTwoMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.EmailTrackingBouncedMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.EmailTrackingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.EnerGuideRurCommentsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ErrorLogsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.FinancialTrackingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.HistoryLogsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.IncentivesAuditDMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.IncentivesAuditEMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.LogsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.MessageCenterAttachmentsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.MessageCenterMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.MessageCenterUserAcknowledgementMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.NotificationsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.OrgAdditionalSettingsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.OrganisationSettingsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.OrgWeeklyAvailabilityMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.OwnershipMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.OwnersMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.PlanUpgradesMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.PropertyMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.ProvinceMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.QaAssessmentDetailMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.QaAssessmentRecordMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.QaCompanySettingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.QaUserSettingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.RegulatoryDocumentMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.TempCustomersMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.TempEAsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.TempJobsLatestUpdatedMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.TempJobsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserAdditionalSettingsMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserBookingMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserClaimStatusMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserClientMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserDetailMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserPropertyMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UsersMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserWeeklyAvailabilityMap());
            modelBuilder.ApplyConfiguration(new EntityCore.Data.Mapping.UserWeeklyScheduleMap());
            #endregion
        }
    }
}
