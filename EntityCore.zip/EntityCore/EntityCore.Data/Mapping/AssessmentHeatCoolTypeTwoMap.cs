using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolTypeTwoMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolTypeTwo>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolTypeTwo> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolTypeTwo", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.TabType)
                .HasColumnName("TabType")
                .HasColumnType("int");

            builder.Property(t => t.UnitFunctionId)
                .HasColumnName("UnitFunctionId")
                .HasColumnType("int");

            builder.Property(t => t.CentralEquipmentTypeId)
                .HasColumnName("CentralEquipmentTypeId")
                .HasColumnType("int");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.OutputCapacity)
                .HasColumnName("OutputCapacity")
                .HasColumnType("int");

            builder.Property(t => t.Capacity)
                .HasColumnName("Capacity")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Efficiency)
                .HasColumnName("Efficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeatingEfficiency)
                .HasColumnName("HeatingEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CoolingEfficiency)
                .HasColumnName("CoolingEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsHeatCOP)
                .HasColumnName("IsHeatCOP")
                .HasColumnType("int");

            builder.Property(t => t.IsHSPF)
                .HasColumnName("IsHSPF")
                .HasColumnType("int");

            builder.Property(t => t.IsCoolCOP)
                .HasColumnName("IsCoolCOP")
                .HasColumnType("int");

            builder.Property(t => t.IsSEER)
                .HasColumnName("IsSEER")
                .HasColumnType("int");

            builder.Property(t => t.TempCutoffId)
                .HasColumnName("TempCutoffId")
                .HasColumnType("int");

            builder.Property(t => t.TempCutoff)
                .HasColumnName("TempCutoff")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TempRatingType)
                .HasColumnName("TempRatingType")
                .HasColumnType("int");

            builder.Property(t => t.RatingTemp)
                .HasColumnName("RatingTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CrankcaseHeater)
                .HasColumnName("CrankcaseHeater")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SensibleHeatRadio)
                .HasColumnName("SensibleHeatRadio")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.OpenableWindowArea)
                .HasColumnName("OpenableWindowArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
