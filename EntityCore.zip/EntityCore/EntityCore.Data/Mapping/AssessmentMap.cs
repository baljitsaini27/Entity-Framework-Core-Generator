using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.Assessment>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.Assessment> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("Assessment", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.ReferanceId)
                .HasColumnName("ReferanceId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentNumber)
                .HasColumnName("AssessmentNumber")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.PrevAssessmentNumber)
                .HasColumnName("PrevAssessmentNumber")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.IsVentilationSystem)
                .HasColumnName("IsVentilationSystem")
                .HasColumnType("int");

            builder.Property(t => t.IsDomesticHotWater)
                .HasColumnName("IsDomesticHotWater")
                .HasColumnType("int");

            builder.Property(t => t.Type)
                .HasColumnName("Type")
                .HasColumnType("int");

            builder.Property(t => t.EvalutionDate)
                .HasColumnName("EvalutionDate")
                .HasColumnType("datetime");

            builder.Property(t => t.SubmittedDate)
                .HasColumnName("SubmittedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.PropertyId)
                .HasColumnName("PropertyId")
                .HasColumnType("bigint");

            builder.Property(t => t.UserId)
                .IsRequired()
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.CompanyId)
                .IsRequired()
                .HasColumnName("CompanyId")
                .HasColumnType("bigint");

            builder.Property(t => t.BatchNumber)
                .HasColumnName("BatchNumber")
                .HasColumnType("varchar(20)")
                .HasMaxLength(20);

            builder.Property(t => t.SuggestEditNotes)
                .HasColumnName("SuggestEditNotes")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.FileRejectedNotes)
                .HasColumnName("FileRejectedNotes")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.IsLatest)
                .IsRequired()
                .HasColumnName("IsLatest")
                .HasColumnType("int");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.BookingId)
                .HasColumnName("BookingId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsElectronicDcf)
                .IsRequired()
                .HasColumnName("IsElectronicDcf")
                .HasColumnType("int");

            builder.Property(t => t.ImportAssessmentId)
                .HasColumnName("ImportAssessmentId")
                .HasColumnType("bigint");

            // relationships
            #endregion
        }

    }
}
