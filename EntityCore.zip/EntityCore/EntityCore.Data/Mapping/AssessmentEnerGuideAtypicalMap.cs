using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentEnerGuideAtypicalMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentEnerGuideAtypical>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentEnerGuideAtypical> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentEnerGuideAtypical", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.EnerGuideId)
                .HasColumnName("EnerGuideId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsDeicingCables)
                .HasColumnName("IsDeicingCables")
                .HasColumnType("int");

            builder.Property(t => t.IsElectricVehicle)
                .HasColumnName("IsElectricVehicle")
                .HasColumnType("int");

            builder.Property(t => t.IsExtensiveExterior)
                .HasColumnName("IsExtensiveExterior")
                .HasColumnType("int");

            builder.Property(t => t.IsHeatedGarage)
                .HasColumnName("IsHeatedGarage")
                .HasColumnType("int");

            builder.Property(t => t.IsHotTub)
                .HasColumnName("IsHotTub")
                .HasColumnType("int");

            builder.Property(t => t.IsMixedUse)
                .HasColumnName("IsMixedUse")
                .HasColumnType("int");

            builder.Property(t => t.IsOutdoorGas)
                .HasColumnName("IsOutdoorGas")
                .HasColumnType("int");

            builder.Property(t => t.IsSwimmingPool)
                .HasColumnName("IsSwimmingPool")
                .HasColumnType("int");

            builder.Property(t => t.IsRoomAC)
                .HasColumnName("IsRoomAC")
                .HasColumnType("int");

            builder.Property(t => t.CountOfUnits)
                .HasColumnName("CountOfUnits")
                .HasColumnType("int");

            builder.Property(t => t.CountOfEnergyStar)
                .HasColumnName("CountOfEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
