using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ElevationTypeOneMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.ElevationTypeOne>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.ElevationTypeOne> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("ElevationTypeOne", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.Location)
                .HasColumnName("Location")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.GableEnds)
                .HasColumnName("GableEnds")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.GableToGableLeft)
                .HasColumnName("GableToGableLeft")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SloppedCeilingArea)
                .HasColumnName("SloppedCeilingArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeightLeft)
                .HasColumnName("HeightLeft")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeightRight)
                .HasColumnName("HeightRight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AverageHeightLeft)
                .HasColumnName("AverageHeightLeft")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AverageHeightRight)
                .HasColumnName("AverageHeightRight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.BaseLeftSide)
                .HasColumnName("BaseLeftSide")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.BaseRightSide)
                .HasColumnName("BaseRightSide")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ModifiedPerimeter)
                .HasColumnName("ModifiedPerimeter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ModifiedHeight)
                .HasColumnName("ModifiedHeight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.GableToGableRight)
                .HasColumnName("GableToGableRight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.VolumeUnderSloppedCeiling)
                .HasColumnName("VolumeUnderSloppedCeiling")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.FloorArea)
                .HasColumnName("FloorArea")
                .HasColumnType("decimal(18, 2)");

            // relationships
            #endregion
        }

    }
}
