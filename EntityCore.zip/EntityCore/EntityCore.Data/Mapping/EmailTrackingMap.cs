using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class EmailTrackingMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.EmailTracking>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.EmailTracking> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("EmailTracking", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.From)
                .IsRequired()
                .HasColumnName("From")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.To)
                .IsRequired()
                .HasColumnName("To")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Subject)
                .HasColumnName("Subject")
                .HasColumnType("varchar(500)")
                .HasMaxLength(500);

            builder.Property(t => t.Body)
                .HasColumnName("Body")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.TrackingId)
                .HasColumnName("TrackingId")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            // relationships
            #endregion
        }

    }
}
