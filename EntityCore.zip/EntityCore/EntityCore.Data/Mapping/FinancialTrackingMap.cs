using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class FinancialTrackingMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.FinancialTracking>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.FinancialTracking> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("FinancialTracking", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.PaymentFor)
                .HasColumnName("PaymentFor")
                .HasColumnType("int");

            builder.Property(t => t.PaymentMethod)
                .HasColumnName("PaymentMethod")
                .HasColumnType("int");

            builder.Property(t => t.CardType)
                .HasColumnName("CardType")
                .HasColumnType("int")
                .HasDefaultValueSql("((0))");

            builder.Property(t => t.ReceiptName)
                .HasColumnName("ReceiptName")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.ReferenceNumber)
                .HasColumnName("ReferenceNumber")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.PaymentDate)
                .HasColumnName("PaymentDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Amount)
                .HasColumnName("Amount")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsRevenueEntered)
                .HasColumnName("IsRevenueEntered")
                .HasColumnType("int");

            builder.Property(t => t.RevenueEntryDate)
                .HasColumnName("RevenueEntryDate")
                .HasColumnType("datetime");

            builder.Property(t => t.IsCostEntered)
                .HasColumnName("IsCostEntered")
                .HasColumnType("int");

            builder.Property(t => t.CostEntryDate)
                .HasColumnName("CostEntryDate")
                .HasColumnType("datetime");

            builder.Property(t => t.IsUnionGas)
                .HasColumnName("IsUnionGas")
                .HasColumnType("int");

            builder.Property(t => t.IsEnbridge)
                .HasColumnName("IsEnbridge")
                .HasColumnType("int");

            builder.Property(t => t.IsIeso)
                .HasColumnName("IsIeso")
                .HasColumnType("int");

            builder.Property(t => t.IsOntario)
                .HasColumnName("IsOntario")
                .HasColumnType("int");

            builder.Property(t => t.HeatingSourceId)
                .HasColumnName("HeatingSourceId")
                .HasColumnType("int");

            builder.Property(t => t.JobTrackingNrcan)
                .HasColumnName("JobTrackingNrcan")
                .HasColumnType("int");

            builder.Property(t => t.JobTrackingNrcanDate)
                .HasColumnName("JobTrackingNrcanDate")
                .HasColumnType("datetime");

            builder.Property(t => t.JobTrackingSo)
                .HasColumnName("JobTrackingSo")
                .HasColumnType("int");

            builder.Property(t => t.JobTrackingSoDate)
                .HasColumnName("JobTrackingSoDate")
                .HasColumnType("datetime");

            builder.Property(t => t.JobTrackingElectronic)
                .HasColumnName("JobTrackingElectronic")
                .HasColumnType("int");

            builder.Property(t => t.JobTrackingElectronicDate)
                .HasColumnName("JobTrackingElectronicDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.RevenueEntryById)
                .HasColumnName("RevenueEntryById")
                .HasColumnType("bigint");

            builder.Property(t => t.CostEntryById)
                .HasColumnName("CostEntryById")
                .HasColumnType("bigint");

            builder.Property(t => t.JobTrackingElectronicById)
                .HasColumnName("JobTrackingElectronicById")
                .HasColumnType("bigint");

            builder.Property(t => t.JobTrackingNrcanById)
                .HasColumnName("JobTrackingNrcanById")
                .HasColumnType("bigint");

            builder.Property(t => t.JobTrackingSoById)
                .HasColumnName("JobTrackingSoById")
                .HasColumnType("bigint");

            // relationships
            #endregion
        }

    }
}
