using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentGenerationPhotoVoltaicMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentGenerationPhotoVoltaic>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentGenerationPhotoVoltaic> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentGenerationPhotoVoltaic", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.GenerationId)
                .IsRequired()
                .HasColumnName("GenerationId")
                .HasColumnType("bigint");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.ArrayArea)
                .HasColumnName("ArrayArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Slope)
                .HasColumnName("Slope")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Azimuth)
                .HasColumnName("Azimuth")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ModuleEfficiency)
                .HasColumnName("ModuleEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CellTemp)
                .HasColumnName("CellTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TempCoefficient)
                .HasColumnName("TempCoefficient")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ArrayLosses)
                .HasColumnName("ArrayLosses")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ConditioningLosses)
                .HasColumnName("ConditioningLosses")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.InverterEfficiency)
                .HasColumnName("InverterEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.GridRate)
                .HasColumnName("GridRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
