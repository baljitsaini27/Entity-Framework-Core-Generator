using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentTemperatureInfoMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentTemperatureInfo>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentTemperatureInfo> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentTemperatureInfo", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .IsRequired()
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.BasementIsHeated)
                .IsRequired()
                .HasColumnName("BasementIsHeated")
                .HasColumnType("int");

            builder.Property(t => t.BasementIsCooled)
                .IsRequired()
                .HasColumnName("BasementIsCooled")
                .HasColumnType("int");

            builder.Property(t => t.IsSeparateThermostat)
                .IsRequired()
                .HasColumnName("IsSeparateThermostat")
                .HasColumnType("int");

            builder.Property(t => t.CrawlSpaceIsHeated)
                .IsRequired()
                .HasColumnName("CrawlSpaceIsHeated")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
