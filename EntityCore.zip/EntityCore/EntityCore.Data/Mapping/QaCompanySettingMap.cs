using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class QaCompanySettingMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.QaCompanySetting>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.QaCompanySetting> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("QaCompanySetting", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.CompanyId)
                .IsRequired()
                .HasColumnName("CompanyId")
                .HasColumnType("bigint");

            builder.Property(t => t.Percentage)
                .IsRequired()
                .HasColumnName("Percentage")
                .HasColumnType("decimal(4, 1)");

            builder.Property(t => t.StartNumber)
                .IsRequired()
                .HasColumnName("StartNumber")
                .HasColumnType("int");

            builder.Property(t => t.EndNumber)
                .IsRequired()
                .HasColumnName("EndNumber")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .IsRequired()
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .IsRequired()
                .HasColumnName("CreatedBy")
                .HasColumnType("varchar(200)")
                .HasMaxLength(200);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("varchar(200)")
                .HasMaxLength(200);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
