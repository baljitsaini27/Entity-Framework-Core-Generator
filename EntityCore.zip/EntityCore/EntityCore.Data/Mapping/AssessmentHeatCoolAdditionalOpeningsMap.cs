using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolAdditionalOpeningsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolAdditionalOpenings>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolAdditionalOpenings> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolAdditionalOpenings", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.EquimentTypeOneId)
                .HasColumnName("EquimentTypeOneId")
                .HasColumnType("int");

            builder.Property(t => t.EquimentTypeTwoId)
                .HasColumnName("EquimentTypeTwoId")
                .HasColumnType("int");

            builder.Property(t => t.EquimentTypeThreeId)
                .HasColumnName("EquimentTypeThreeId")
                .HasColumnType("int");

            builder.Property(t => t.FlueDiameterOne)
                .HasColumnName("FlueDiameterOne")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlueDiameterTwo)
                .HasColumnName("FlueDiameterTwo")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlueDiameterThree)
                .HasColumnName("FlueDiameterThree")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsDamperClosedOne)
                .HasColumnName("IsDamperClosedOne")
                .HasColumnType("int");

            builder.Property(t => t.IsDamperClosedTwo)
                .HasColumnName("IsDamperClosedTwo")
                .HasColumnType("int");

            builder.Property(t => t.IsDamperClosedThree)
                .HasColumnName("IsDamperClosedThree")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
