using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentVentilationTypesMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentVentilationTypes>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentVentilationTypes> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentVentilationTypes", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.VentilationId)
                .HasColumnName("VentilationId")
                .HasColumnType("bigint");

            builder.Property(t => t.VentilatorTypeId)
                .HasColumnName("VentilatorTypeId")
                .HasColumnType("int");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsHVI)
                .HasColumnName("IsHVI")
                .HasColumnType("int");

            builder.Property(t => t.AirflowRateSupply)
                .HasColumnName("AirflowRateSupply")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Exhaust)
                .HasColumnName("Exhaust")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsDefaultFanPower)
                .HasColumnName("IsDefaultFanPower")
                .HasColumnType("int");

            builder.Property(t => t.FanPower)
                .HasColumnName("FanPower")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition1Preheater)
                .HasColumnName("Condition1Preheater")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition1Temperature)
                .HasColumnName("Condition1Temperature")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition1Effciency)
                .HasColumnName("Condition1Effciency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition2Preheater)
                .HasColumnName("Condition2Preheater")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition2Temperature)
                .HasColumnName("Condition2Temperature")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Condition2Effciency)
                .HasColumnName("Condition2Effciency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.PreHeaterCapacity)
                .HasColumnName("PreHeaterCapacity")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.LowTempVentilation)
                .HasColumnName("LowTempVentilation")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CoolingEfficiency)
                .HasColumnName("CoolingEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Type)
                .HasColumnName("Type")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
