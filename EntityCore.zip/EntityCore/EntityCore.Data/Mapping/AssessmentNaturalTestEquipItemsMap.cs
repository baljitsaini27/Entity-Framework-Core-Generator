using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentNaturalTestEquipItemsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentNaturalTestEquipItems>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentNaturalTestEquipItems> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentNaturalTestEquipItems", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.TestEquipId)
                .IsRequired()
                .HasColumnName("TestEquipId")
                .HasColumnType("bigint");

            builder.Property(t => t.Type)
                .HasColumnName("Type")
                .HasColumnType("int");

            builder.Property(t => t.HsePressureType)
                .HasColumnName("HsePressureType")
                .HasColumnType("int");

            builder.Property(t => t.HsePressure)
                .HasColumnName("HsePressure")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FanPressure)
                .HasColumnName("FanPressure")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.MeasuredFlow)
                .HasColumnName("MeasuredFlow")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlowRangeId)
                .HasColumnName("FlowRangeId")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
