using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class TempJobsLatestUpdatedMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.TempJobsLatestUpdated>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.TempJobsLatestUpdated> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("TempJobsLatestUpdated", "dbo");

            // properties
            builder.Property(t => t.Propertyid)
                .HasColumnName("PROPERTYID")
                .HasColumnType("bigint");

            builder.Property(t => t.Userid)
                .HasColumnName("USERID")
                .HasColumnType("bigint");

            builder.Property(t => t.Project)
                .HasColumnName("Project")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Id)
                .HasColumnName("ID")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.AboutUs)
                .HasColumnName("AboutUs")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Ea)
                .HasColumnName("EA")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Customer)
                .HasColumnName("Customer")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Followup)
                .HasColumnName("followup")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.JobNumber)
                .HasColumnName("JobNumber")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.JobType)
                .HasColumnName("JobType")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.EnergyProgram)
                .HasColumnName("EnergyProgram")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CivicNnumber)
                .HasColumnName("CivicNnumber")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Street)
                .HasColumnName("Street")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.City)
                .HasColumnName("City")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Provice)
                .HasColumnName("Provice")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Postal1)
                .HasColumnName("Postal1")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Postal2)
                .HasColumnName("Postal2")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Fee)
                .HasColumnName("Fee")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.PaymentMethod)
                .HasColumnName("PaymentMethod")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Cheque)
                .HasColumnName("Cheque")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.QBrevenue)
                .HasColumnName("QBrevenue")
                .HasColumnType("datetime");

            builder.Property(t => t.QBCost)
                .HasColumnName("QBCost")
                .HasColumnType("datetime");

            builder.Property(t => t.Appointment)
                .HasColumnName("Appointment")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Month)
                .HasColumnName("Month")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.NumberOfJob)
                .HasColumnName("NumberOfJob")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.EleFiles)
                .HasColumnName("EleFiles")
                .HasColumnType("datetime");

            builder.Property(t => t.FileUploadDB)
                .HasColumnName("FileUploadDB")
                .HasColumnType("datetime");

            builder.Property(t => t.FileAcceptNRCan)
                .HasColumnName("File Accept NRCan")
                .HasColumnType("datetime");

            builder.Property(t => t.NRCanBatch)
                .HasColumnName("NRCanBatch")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.JobStatus)
                .HasColumnName("Job Status")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.FormReceive)
                .HasColumnName("FormReceive")
                .HasColumnType("datetime");

            builder.Property(t => t.FormSentNRCan)
                .HasColumnName("FormSentNRCan")
                .HasColumnType("datetime");

            builder.Property(t => t.ReportSent)
                .HasColumnName("ReportSent")
                .HasColumnType("datetime");

            builder.Property(t => t.FileAuditDate)
                .HasColumnName("FileAuditDate")
                .HasColumnType("datetime");

            // relationships
            #endregion
        }

    }
}
