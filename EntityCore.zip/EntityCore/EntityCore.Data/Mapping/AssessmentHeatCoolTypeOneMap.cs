using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolTypeOneMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolTypeOne>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolTypeOne> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolTypeOne", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.TabType)
                .HasColumnName("TabType")
                .HasColumnType("int");

            builder.Property(t => t.EnergySourceId)
                .HasColumnName("EnergySourceId")
                .HasColumnType("int");

            builder.Property(t => t.IsDueFuel)
                .HasColumnName("IsDueFuel")
                .HasColumnType("int");

            builder.Property(t => t.SwitchOverTemp)
                .HasColumnName("SwitchOverTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EquipmentType)
                .HasColumnName("EquipmentType")
                .HasColumnType("int");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsEPA)
                .HasColumnName("IsEPA")
                .HasColumnType("int");

            builder.Property(t => t.OutputCapacity)
                .HasColumnName("OutputCapacity")
                .HasColumnType("int");

            builder.Property(t => t.Value)
                .HasColumnName("Value")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SizingFactor)
                .HasColumnName("SizingFactor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Efficiency)
                .HasColumnName("Efficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsSteadyState)
                .HasColumnName("IsSteadyState")
                .HasColumnType("int");

            builder.Property(t => t.IsAFUE)
                .HasColumnName("IsAFUE")
                .HasColumnType("int");

            builder.Property(t => t.PilotLight)
                .HasColumnName("PilotLight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlueDiameter)
                .HasColumnName("FlueDiameter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TankVolumeId)
                .HasColumnName("TankVolumeId")
                .HasColumnType("int");

            builder.Property(t => t.TankVolume)
                .HasColumnName("TankVolume")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EnergyFactorId)
                .HasColumnName("EnergyFactorId")
                .HasColumnType("int");

            builder.Property(t => t.EnergyFactor)
                .HasColumnName("EnergyFactor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TankLocationId)
                .HasColumnName("TankLocationId")
                .HasColumnType("int");

            builder.Property(t => t.CirculationPumpId)
                .HasColumnName("CirculationPumpId")
                .HasColumnType("int");

            builder.Property(t => t.CirculationPumpValue)
                .HasColumnName("CirculationPumpValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsEnergyPumpMotor)
                .HasColumnName("IsEnergyPumpMotor")
                .HasColumnType("int");

            builder.Property(t => t.IsDrainWaterHeat)
                .HasColumnName("IsDrainWaterHeat")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
