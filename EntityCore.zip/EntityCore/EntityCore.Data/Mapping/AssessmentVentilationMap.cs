using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentVentilationMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentVentilation>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentVentilation> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentVentilation", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .IsRequired()
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.CirculationTypeId)
                .HasColumnName("CirculationTypeId")
                .HasColumnType("int");

            builder.Property(t => t.VentilatorTypeId)
                .HasColumnName("VentilatorTypeId")
                .HasColumnType("int");

            builder.Property(t => t.SupplyFlowRate)
                .HasColumnName("SupplyFlowRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ExhaustFlowRate)
                .HasColumnName("ExhaustFlowRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ComponentTypeId)
                .HasColumnName("ComponentTypeId")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
