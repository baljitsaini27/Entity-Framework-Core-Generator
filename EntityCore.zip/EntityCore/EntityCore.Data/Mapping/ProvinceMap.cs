using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ProvinceMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.Province>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.Province> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("Province", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("int")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.ProvinceName)
                .IsRequired()
                .HasColumnName("ProvinceName")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
