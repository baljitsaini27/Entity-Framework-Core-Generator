using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class UserBookingMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.UserBooking>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.UserBooking> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("UserBooking", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.EventId)
                .HasColumnName("EventId")
                .HasColumnType("bigint");

            builder.Property(t => t.PropertyId)
                .HasColumnName("PropertyId")
                .HasColumnType("bigint");

            builder.Property(t => t.Cost)
                .HasColumnName("Cost")
                .HasColumnType("decimal(18, 1)");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.BookingType)
                .HasColumnName("BookingType")
                .HasColumnType("varchar(1)")
                .HasMaxLength(1);

            builder.Property(t => t.AssessmentType)
                .HasColumnName("AssessmentType")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
