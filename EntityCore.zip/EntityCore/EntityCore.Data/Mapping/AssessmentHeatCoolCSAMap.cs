using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolCSAMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolCSA>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolCSA> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolCSA", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.ManufacturerId)
                .HasColumnName("ManufacturerId")
                .HasColumnType("bigint");

            builder.Property(t => t.ModelId)
                .HasColumnName("ModelId")
                .HasColumnType("bigint");

            builder.Property(t => t.NumberOfP9)
                .HasColumnName("NumberOfP9")
                .HasColumnType("int");

            builder.Property(t => t.ThermalPerformanceFactor)
                .HasColumnName("ThermalPerformanceFactor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ElectricalConsumption)
                .HasColumnName("ElectricalConsumption")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeatingCapacity)
                .HasColumnName("HeatingCapacity")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeatingEfficiency)
                .HasColumnName("HeatingEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.WaterPerformanceFactor)
                .HasColumnName("WaterPerformanceFactor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.NormalBurnerInput)
                .HasColumnName("NormalBurnerInput")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.RecoveryEfficiency)
                .HasColumnName("RecoveryEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsDrainWaterHeat)
                .HasColumnName("IsDrainWaterHeat")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
