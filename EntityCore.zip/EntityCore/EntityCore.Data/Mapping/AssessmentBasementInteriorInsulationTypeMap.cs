using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentBasementInteriorInsulationTypeMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentBasementInteriorInsulationType>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentBasementInteriorInsulationType> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentBasementInteriorInsulationType", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.Name)
                .HasColumnName("Name")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.InternalCode)
                .HasColumnName("InternalCode")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.FramingId)
                .HasColumnName("FramingId")
                .HasColumnType("bigint");

            builder.Property(t => t.SpacingId)
                .HasColumnName("SpacingId")
                .HasColumnType("bigint");

            builder.Property(t => t.StudsId)
                .HasColumnName("StudsId")
                .HasColumnType("bigint");

            builder.Property(t => t.InsulationLayerId)
                .HasColumnName("InsulationLayerId")
                .HasColumnType("bigint");

            builder.Property(t => t.ExtraInsulationLayerId)
                .HasColumnName("ExtraInsulationLayerId")
                .HasColumnType("bigint");

            builder.Property(t => t.InteriorFinishId)
                .HasColumnName("InteriorFinishId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsDefault)
                .HasColumnName("IsDefault")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
