using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentCrawlSpaceMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentCrawlSpace>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentCrawlSpace> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentCrawlSpace", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.Name)
                .HasColumnName("Name")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.CrawlSpaceTypeId)
                .HasColumnName("CrawlSpaceTypeId")
                .HasColumnType("int");

            builder.Property(t => t.IsRectangular)
                .HasColumnName("IsRectangular")
                .HasColumnType("int");

            builder.Property(t => t.IsNonRectangular)
                .HasColumnName("IsNonRectangular")
                .HasColumnType("int");

            builder.Property(t => t.Length)
                .HasColumnName("Length")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Width)
                .HasColumnName("Width")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Perimeter)
                .HasColumnName("Perimeter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TotalArea)
                .HasColumnName("TotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TotalWallHeight)
                .HasColumnName("TotalWallHeight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.DepthBelowGrade)
                .HasColumnName("DepthBelowGrade")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ExposedSurfacesPerimeter)
                .HasColumnName("ExposedSurfacesPerimeter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
