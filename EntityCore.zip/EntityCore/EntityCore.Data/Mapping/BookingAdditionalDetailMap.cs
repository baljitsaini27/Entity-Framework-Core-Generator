using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class BookingAdditionalDetailMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.BookingAdditionalDetail>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.BookingAdditionalDetail> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("BookingAdditionalDetail", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.BookingId)
                .IsRequired()
                .HasColumnName("BookingId")
                .HasColumnType("bigint");

            builder.Property(t => t.HouseTypeId)
                .HasColumnName("HouseTypeId")
                .HasColumnType("int");

            builder.Property(t => t.StoreysId)
                .HasColumnName("StoreysId")
                .HasColumnType("int");

            builder.Property(t => t.YearBuiltId)
                .HasColumnName("YearBuiltId")
                .HasColumnType("int");

            builder.Property(t => t.Year)
                .HasColumnName("Year")
                .HasColumnType("int");

            builder.Property(t => t.HouseSize)
                .HasColumnName("HouseSize")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsBasementInsulation)
                .HasColumnName("IsBasementInsulation")
                .HasColumnType("int");

            builder.Property(t => t.IsCrawlspaceInsulation)
                .HasColumnName("IsCrawlspaceInsulation")
                .HasColumnType("int");

            builder.Property(t => t.IsMainWallInsulation)
                .HasColumnName("IsMainWallInsulation")
                .HasColumnType("int");

            builder.Property(t => t.IsAtticInsulation)
                .HasColumnName("IsAtticInsulation")
                .HasColumnType("int");

            builder.Property(t => t.IsAttic)
                .HasColumnName("IsAttic")
                .HasColumnType("int");

            builder.Property(t => t.IsCrawlspace)
                .HasColumnName("IsCrawlspace")
                .HasColumnType("int");

            builder.Property(t => t.IsCleaned)
                .HasColumnName("IsCleaned")
                .HasColumnType("int");

            builder.Property(t => t.WoodBurningAppliances)
                .HasColumnName("WoodBurningAppliances")
                .HasColumnType("int");

            builder.Property(t => t.QuotedPrice)
                .HasColumnName("QuotedPrice")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Windows)
                .HasColumnName("Windows")
                .HasColumnType("int");

            builder.Property(t => t.Doors)
                .HasColumnName("Doors")
                .HasColumnType("int");

            builder.Property(t => t.SkyLights)
                .HasColumnName("SkyLights")
                .HasColumnType("int");

            builder.Property(t => t.HeatingSystem)
                .HasColumnName("HeatingSystem")
                .HasColumnType("int");

            builder.Property(t => t.CoolingSystem)
                .HasColumnName("CoolingSystem")
                .HasColumnType("int");

            builder.Property(t => t.HotWater)
                .HasColumnName("HotWater")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .IsRequired()
                .HasColumnName("CreatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CreatedDate)
                .IsRequired()
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.IsMainHeatingSystem)
                .HasColumnName("IsMainHeatingSystem")
                .HasColumnType("int");

            builder.Property(t => t.IsAirConditioning)
                .HasColumnName("IsAirConditioning")
                .HasColumnType("int");

            builder.Property(t => t.IsDomesticHotWater)
                .HasColumnName("IsDomesticHotWater")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
