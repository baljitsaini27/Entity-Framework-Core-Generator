using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class MessageCenterUserAcknowledgementMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.MessageCenterUserAcknowledgement>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.MessageCenterUserAcknowledgement> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("MessageCenterUserAcknowledgement", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.MessageId)
                .HasColumnName("MessageId")
                .HasColumnType("bigint");

            builder.Property(t => t.UserId)
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsAcknowledged)
                .HasColumnName("IsAcknowledged")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
