using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolCSADetailsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolCSADetails>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolCSADetails> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolCSADetails", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolCSAId)
                .HasColumnName("HeatingCoolCSAId")
                .HasColumnType("bigint");

            builder.Property(t => t.ManufacturerId)
                .HasColumnName("ManufacturerId")
                .HasColumnType("bigint");

            builder.Property(t => t.ModelId)
                .HasColumnName("ModelId")
                .HasColumnType("bigint");

            builder.Property(t => t.EnergySourceId)
                .HasColumnName("EnergySourceId")
                .HasColumnType("int");

            builder.Property(t => t.NetEfficiency1)
                .HasColumnName("NetEfficiency1")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.NetEfficiency2)
                .HasColumnName("NetEfficiency2")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.NetEfficiency3)
                .HasColumnName("NetEfficiency3")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AverageElectrical1)
                .HasColumnName("AverageElectrical1")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AverageElectrical2)
                .HasColumnName("AverageElectrical2")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AverageElectrical3)
                .HasColumnName("AverageElectrical3")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.MotorPower1)
                .HasColumnName("MotorPower1")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.MotorPower2)
                .HasColumnName("MotorPower2")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.MotorPower3)
                .HasColumnName("MotorPower3")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Pcont)
                .HasColumnName("Pcont")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Pcirc)
                .HasColumnName("Pcirc")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.DailyElectricityUse)
                .HasColumnName("DailyElectricityUse")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FanOn)
                .HasColumnName("FanOn")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FanOff)
                .HasColumnName("FanOff")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.DHWonly)
                .HasColumnName("DHWonly")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SHload)
                .HasColumnName("SHload")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
