using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentEnerGuideHouseHoldMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentEnerGuideHouseHold>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentEnerGuideHouseHold> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentEnerGuideHouseHold", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.EnerGuideId)
                .HasColumnName("EnerGuideId")
                .HasColumnType("bigint");

            builder.Property(t => t.NumberOfOccupants)
                .HasColumnName("NumberOfOccupants")
                .HasColumnType("int");

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.DayTime)
                .HasColumnName("DayTime")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.NightTime)
                .HasColumnName("NightTime")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CoolingSeason)
                .HasColumnName("CoolingSeason")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsLEDBulbs)
                .HasColumnName("IsLEDBulbs")
                .HasColumnType("int");

            builder.Property(t => t.IsYearOld)
                .HasColumnName("IsYearOld")
                .HasColumnType("int");

            builder.Property(t => t.CoolingSeasonMonth)
                .HasColumnName("CoolingSeasonMonth")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
