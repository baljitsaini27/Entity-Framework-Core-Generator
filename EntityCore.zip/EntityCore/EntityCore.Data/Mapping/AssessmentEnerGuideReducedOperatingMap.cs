using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentEnerGuideReducedOperatingMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentEnerGuideReducedOperating>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentEnerGuideReducedOperating> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentEnerGuideReducedOperating", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.EnerGuideId)
                .HasColumnName("EnerGuideId")
                .HasColumnType("bigint");

            builder.Property(t => t.LightingId)
                .HasColumnName("LightingId")
                .HasColumnType("int");

            builder.Property(t => t.ClothesDryer)
                .HasColumnName("ClothesDryer")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ClothesWasher)
                .HasColumnName("ClothesWasher")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.DishWasher)
                .HasColumnName("DishWasher")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Refrigerator)
                .HasColumnName("Refrigerator")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Range)
                .HasColumnName("Range")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsClothWasherEnergyStar)
                .HasColumnName("IsClothWasherEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsDishWasherEnergyStar)
                .HasColumnName("IsDishWasherEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsBathroomFaucets)
                .HasColumnName("IsBathroomFaucets")
                .HasColumnType("int");

            builder.Property(t => t.IsShowerHeads)
                .HasColumnName("IsShowerHeads")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
