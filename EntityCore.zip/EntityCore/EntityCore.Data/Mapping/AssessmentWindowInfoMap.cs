using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentWindowInfoMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentWindowInfo>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentWindowInfo> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentWindowInfo", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .IsRequired()
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.Name)
                .IsRequired()
                .HasColumnName("Name")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Number)
                .HasColumnName("Number")
                .HasColumnType("int");

            builder.Property(t => t.WindowTypeId)
                .HasColumnName("WindowTypeId")
                .HasColumnType("bigint");

            builder.Property(t => t.OrientationId)
                .HasColumnName("OrientationId")
                .HasColumnType("bigint");

            builder.Property(t => t.TiltId)
                .HasColumnName("TiltId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.Width)
                .HasColumnName("width")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Height)
                .HasColumnName("Height")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.GrossArea)
                .HasColumnName("GrossArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.OverHangWidth)
                .HasColumnName("OverHangWidth")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeaderHeight)
                .HasColumnName("HeaderHeight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Value)
                .HasColumnName("Value")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
