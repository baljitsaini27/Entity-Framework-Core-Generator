using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ElevationTypeTwoMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.ElevationTypeTwo>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.ElevationTypeTwo> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("ElevationTypeTwo", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.GableToGable)
                .HasColumnName("GableToGable")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SloppedCeilingArea)
                .HasColumnName("SloppedCeilingArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlatCeilingArea)
                .HasColumnName("FlatCeilingArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FloorArea)
                .HasColumnName("FloorArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FloorVolume)
                .HasColumnName("FloorVolume")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlatCeilingWidth)
                .HasColumnName("FlatCeilingWidth")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeightFromFloor)
                .HasColumnName("HeightFromFloor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.KneeWallHeight)
                .HasColumnName("KneeWallHeight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.KneeWallToKneeWall)
                .HasColumnName("KneeWallToKneeWall")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EaveTroughToEaveTrough)
                .HasColumnName("EaveTroughToEaveTrough")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HeaderPerimeter)
                .HasColumnName("HeaderPerimeter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.WallArea)
                .HasColumnName("WallArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SloppedCeilingLength)
                .HasColumnName("SloppedCeilingLength")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.GrablePerimeter)
                .HasColumnName("GrablePerimeter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.KneewallPer)
                .HasColumnName("KneewallPer")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AvGableWallHeight)
                .HasColumnName("AvGableWallHeight")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.FlatCeilingBehind)
                .HasColumnName("FlatCeilingBehind")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlatCeilingAbove)
                .HasColumnName("FlatCeilingAbove")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AreaGableWalls)
                .HasColumnName("AreaGableWalls")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AreaKneeWalls)
                .HasColumnName("AreaKneeWalls")
                .HasColumnType("decimal(18, 2)");

            // relationships
            #endregion
        }

    }
}
