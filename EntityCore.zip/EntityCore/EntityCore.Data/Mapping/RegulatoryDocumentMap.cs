using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class RegulatoryDocumentMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.RegulatoryDocument>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.RegulatoryDocument> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("RegulatoryDocument", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.CompanyId)
                .IsRequired()
                .HasColumnName("CompanyId")
                .HasColumnType("bigint");

            builder.Property(t => t.Name)
                .HasColumnName("Name")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.FileName)
                .IsRequired()
                .HasColumnName("FileName")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.CreatedDate)
                .IsRequired()
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .IsRequired()
                .HasColumnName("CreatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
