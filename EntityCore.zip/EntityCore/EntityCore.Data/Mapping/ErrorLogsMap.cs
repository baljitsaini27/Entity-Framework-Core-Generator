using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ErrorLogsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.ErrorLogs>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.ErrorLogs> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("ErrorLogs", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("ID")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.ErrorNumber)
                .HasColumnName("ErrorNumber")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.ErrorSeverity)
                .HasColumnName("ErrorSeverity")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.ErrorState)
                .HasColumnName("ErrorState")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.ErrorProcedure)
                .HasColumnName("ErrorProcedure")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.ErrorLine)
                .HasColumnName("ErrorLine")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.ErrorMessage)
                .HasColumnName("ErrorMessage")
                .HasColumnType("varchar(max)");

            // relationships
            #endregion
        }

    }
}
