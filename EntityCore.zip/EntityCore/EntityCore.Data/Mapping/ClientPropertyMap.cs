using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ClientPropertyMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.ClientProperty>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.ClientProperty> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("ClientProperty", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.ClientId)
                .IsRequired()
                .HasColumnName("ClientId")
                .HasColumnType("bigint");

            builder.Property(t => t.PropertyId)
                .IsRequired()
                .HasColumnName("PropertyId")
                .HasColumnType("bigint");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            builder.HasOne(t => t.Client)
                .WithMany(t => t.ClientProperties)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK_ClientProperty_Client");

            builder.HasOne(t => t.Property)
                .WithMany(t => t.ClientProperties)
                .HasForeignKey(d => d.PropertyId)
                .HasConstraintName("FK_ClientProperty_Property");

            #endregion
        }

    }
}
