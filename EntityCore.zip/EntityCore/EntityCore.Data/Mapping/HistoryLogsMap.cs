using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class HistoryLogsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.HistoryLogs>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.HistoryLogs> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("HistoryLogs", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.EventName)
                .IsRequired()
                .HasColumnName("EventName")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.EventDescription)
                .IsRequired()
                .HasColumnName("EventDescription")
                .HasColumnType("nvarchar(max)");

            builder.Property(t => t.CreatedFor)
                .IsRequired()
                .HasColumnName("CreatedFor")
                .HasColumnType("bigint");

            builder.Property(t => t.CreatedDate)
                .IsRequired()
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .IsRequired()
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            // relationships
            #endregion
        }

    }
}
