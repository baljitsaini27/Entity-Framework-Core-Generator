using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class EmailTrackingBouncedMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.EmailTrackingBounced>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.EmailTrackingBounced> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("EmailTrackingBounced", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.From)
                .HasColumnName("From")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.To)
                .HasColumnName("To")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Bcc)
                .HasColumnName("Bcc")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Cc)
                .HasColumnName("CC")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Subject)
                .HasColumnName("Subject")
                .HasColumnType("varchar(500)")
                .HasMaxLength(500);

            builder.Property(t => t.Body)
                .HasColumnName("Body")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.TextBody)
                .HasColumnName("TextBody")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.SentDate)
                .HasColumnName("SentDate")
                .HasColumnType("datetime");

            builder.Property(t => t.MessageUid)
                .IsRequired()
                .HasColumnName("MessageUid")
                .HasColumnType("varchar(500)")
                .HasMaxLength(500);

            builder.Property(t => t.BuywiseTrackingId)
                .HasColumnName("BuywiseTrackingId")
                .HasColumnType("varchar(500)")
                .HasMaxLength(500);

            builder.Property(t => t.ReasonToFailed)
                .HasColumnName("ReasonToFailed")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
