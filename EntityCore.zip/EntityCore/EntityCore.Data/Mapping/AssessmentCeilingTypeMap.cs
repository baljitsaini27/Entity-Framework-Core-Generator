using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentCeilingTypeMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentCeilingType>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentCeilingType> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentCeilingType", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.Name)
                .HasColumnName("Name")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.StructureTypeId)
                .HasColumnName("StructureTypeId")
                .HasColumnType("bigint");

            builder.Property(t => t.ComponentTypeId)
                .HasColumnName("ComponentTypeId")
                .HasColumnType("bigint");

            builder.Property(t => t.SpacingId)
                .HasColumnName("SpacingId")
                .HasColumnType("bigint");

            builder.Property(t => t.InsulationLayerOneId)
                .HasColumnName("InsulationLayerOneId")
                .HasColumnType("bigint");

            builder.Property(t => t.InsulationLayerTwoId)
                .HasColumnName("InsulationLayerTwoId")
                .HasColumnType("bigint");

            builder.Property(t => t.InteriorId)
                .HasColumnName("InteriorId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsDefault)
                .HasColumnName("IsDefault")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
