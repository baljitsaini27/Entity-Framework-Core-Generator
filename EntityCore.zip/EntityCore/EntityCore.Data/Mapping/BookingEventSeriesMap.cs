using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class BookingEventSeriesMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.BookingEventSeries>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.BookingEventSeries> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("BookingEventSeries", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.UserId)
                .IsRequired()
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.Occurrences)
                .HasColumnName("Occurrences")
                .HasColumnType("int");

            builder.Property(t => t.ReOccurrenceType)
                .HasColumnName("ReOccurrenceType")
                .HasColumnType("int");

            builder.Property(t => t.StartDate)
                .HasColumnName("StartDate")
                .HasColumnType("datetime");

            builder.Property(t => t.EndDate)
                .HasColumnName("EndDate")
                .HasColumnType("datetime");

            builder.Property(t => t.RecurrEvery)
                .HasColumnName("RecurrEvery")
                .HasColumnType("int");

            builder.Property(t => t.DailyType)
                .HasColumnName("DailyType")
                .HasColumnType("int");

            builder.Property(t => t.WeekDays)
                .HasColumnName("WeekDays")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            // relationships
            #endregion
        }

    }
}
