using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AspNetRolesMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AspNetRoles>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AspNetRoles> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AspNetRoles", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.ConcurrencyStamp)
                .HasColumnName("ConcurrencyStamp")
                .HasColumnType("nvarchar(max)");

            builder.Property(t => t.Name)
                .HasColumnName("Name")
                .HasColumnType("nvarchar(256)")
                .HasMaxLength(256);

            builder.Property(t => t.NormalizedName)
                .HasColumnName("NormalizedName")
                .HasColumnType("nvarchar(256)")
                .HasMaxLength(256);

            // relationships
            #endregion
        }

    }
}
