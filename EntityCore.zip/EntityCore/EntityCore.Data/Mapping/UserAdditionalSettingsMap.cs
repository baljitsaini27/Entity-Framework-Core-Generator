using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class UserAdditionalSettingsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.UserAdditionalSettings>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.UserAdditionalSettings> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("UserAdditionalSettings", "dbo");

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.UserId)
                .IsRequired()
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.StandardRateFileD)
                .HasColumnName("StandardRateFileD")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.StandardRateFileE)
                .HasColumnName("StandardRateFileE")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.StandardTimeFileD)
                .HasColumnName("StandardTimeFileD")
                .HasColumnType("int");

            builder.Property(t => t.StandardTimeFileE)
                .HasColumnName("StandardTimeFileE")
                .HasColumnType("int");

            builder.Property(t => t.BaseHouseSize)
                .HasColumnName("BaseHouseSize")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AdditionalAreaSize)
                .HasColumnName("AdditionalAreaSize")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AdditionalAreaRate)
                .HasColumnName("AdditionalAreaRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.MaxTravelDistance)
                .HasColumnName("MaxTravelDistance")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TravelRadius)
                .HasColumnName("TravelRadius")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AdditionalTravelDistance)
                .HasColumnName("AdditionalTravelDistance")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AdditionalTravelRate)
                .HasColumnName("AdditionalTravelRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            // relationships
            #endregion
        }

    }
}
