using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class UsersMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.Users>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.Users> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("Users", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.Code)
                .HasColumnName("Code")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.FirstName)
                .IsRequired()
                .HasColumnName("FirstName")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.LastName)
                .IsRequired()
                .HasColumnName("LastName")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Image)
                .HasColumnName("Image")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.CompanyId)
                .IsRequired()
                .HasColumnName("CompanyId")
                .HasColumnType("bigint");

            builder.Property(t => t.AspNetUserId)
                .IsRequired()
                .HasColumnName("AspNetUserId")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UserType)
                .IsRequired()
                .HasColumnName("UserType")
                .HasColumnType("int");

            builder.Property(t => t.IsEnergyAdvisor)
                .IsRequired()
                .HasColumnName("IsEnergyAdvisor")
                .HasColumnType("int");

            builder.Property(t => t.IsQa)
                .IsRequired()
                .HasColumnName("IsQa")
                .HasColumnType("int");

            builder.Property(t => t.IsExclude)
                .HasColumnName("IsExclude")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.IsSchedular)
                .IsRequired()
                .HasColumnName("IsSchedular")
                .HasColumnType("int");

            builder.Property(t => t.IsElectronicDcf)
                .IsRequired()
                .HasColumnName("IsElectronicDcf")
                .HasColumnType("int");

            builder.Property(t => t.TimeZone)
                .HasColumnName("TimeZone")
                .HasColumnType("int");

            builder.Property(t => t.IsWifiUploadEnabled)
                .HasColumnName("IsWifiUploadEnabled")
                .HasColumnType("int");

            builder.Property(t => t.GoogleMail)
                .HasColumnName("GoogleMail")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.AssessmentSeries)
                .HasColumnName("AssessmentSeries")
                .HasColumnType("varchar(10)")
                .HasMaxLength(10);

            builder.Property(t => t.LastAssessmentNumber)
                .HasColumnName("LastAssessmentNumber")
                .HasColumnType("varchar(10)")
                .HasMaxLength(10);

            // relationships
            builder.HasOne(t => t.AspNetUserAspNetUsers)
                .WithMany(t => t.AspNetUserUsers)
                .HasForeignKey(d => d.AspNetUserId)
                .HasConstraintName("FK_Users_AspNetUsers");

            builder.HasOne(t => t.Company)
                .WithMany(t => t.Users)
                .HasForeignKey(d => d.CompanyId)
                .HasConstraintName("FK_Users_Company");

            #endregion
        }

    }
}
