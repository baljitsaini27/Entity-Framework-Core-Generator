using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentNaturalTestEquipMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentNaturalTestEquip>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentNaturalTestEquip> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentNaturalTestEquip", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.NaturalAirLeakageId)
                .IsRequired()
                .HasColumnName("NaturalAirLeakageId")
                .HasColumnType("bigint");

            builder.Property(t => t.FanTypeId)
                .HasColumnName("FanTypeId")
                .HasColumnType("int");

            builder.Property(t => t.OldFanTypeId)
                .HasColumnName("OldFanTypeId")
                .HasColumnType("int");

            builder.Property(t => t.Manometer)
                .HasColumnName("Manometer")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.IsBaseLine)
                .HasColumnName("IsBaseLine")
                .HasColumnType("int");

            builder.Property(t => t.InitialPressure)
                .HasColumnName("InitialPressure")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FinalPressure)
                .HasColumnName("FinalPressure")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.InsideTemperature)
                .HasColumnName("InsideTemperature")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ZoneHeatedVol)
                .HasColumnName("ZoneHeatedVol")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
