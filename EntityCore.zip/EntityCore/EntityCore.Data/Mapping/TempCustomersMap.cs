using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class TempCustomersMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.TempCustomers>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.TempCustomers> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("TempCustomers", "dbo");

            // properties
            builder.Property(t => t.Project)
                .HasColumnName("Project")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Id)
                .HasColumnName("ID")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.FirstName)
                .HasColumnName("First Name")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.LastName)
                .HasColumnName("Last Name")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Phone)
                .HasColumnName("Phone")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Email)
                .HasColumnName("Email")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CivicNumber)
                .HasColumnName("Civic Number")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Street)
                .HasColumnName("Street")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.City)
                .HasColumnName("City")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.Province)
                .HasColumnName("Province")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.PostalCodeFSA)
                .HasColumnName("Postal Code FSA")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.PostalCodeLDU)
                .HasColumnName("Postal Code LDU")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CustomerNote)
                .HasColumnName("Customer Note")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CreatedOn)
                .HasColumnName("Created On")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("Created By")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.File)
                .HasColumnName("File")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.AddedOn)
                .HasColumnName("Added On")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.AddedBy)
                .HasColumnName("Added By")
                .HasColumnType("varchar(max)");

            // relationships
            #endregion
        }

    }
}
