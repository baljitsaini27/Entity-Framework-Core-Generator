using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentDHWMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentDHW>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentDHW> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentDHW", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.DHWType)
                .HasColumnName("DHWType")
                .HasColumnType("int");

            builder.Property(t => t.EnergySourceId)
                .HasColumnName("EnergySourceId")
                .HasColumnType("int");

            builder.Property(t => t.TankTypeId)
                .HasColumnName("TankTypeId")
                .HasColumnType("int");

            builder.Property(t => t.TankVolumeId)
                .HasColumnName("TankVolumeId")
                .HasColumnType("int");

            builder.Property(t => t.TankVolume)
                .HasColumnName("TankVolume")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EnergyFactorId)
                .HasColumnName("EnergyFactorId")
                .HasColumnType("int");

            builder.Property(t => t.EnergyFactor)
                .HasColumnName("EnergyFactor")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TankLocationId)
                .HasColumnName("TankLocationId")
                .HasColumnType("int");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsEcoEnergy)
                .HasColumnName("IsEcoEnergy")
                .HasColumnType("int");

            builder.Property(t => t.InsulatingBlanket)
                .HasColumnName("InsulatingBlanket")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Hpcop)
                .HasColumnName("HPCOP")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.StandByHeatLoss)
                .HasColumnName("StandByHeatLoss")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsW)
                .HasColumnName("IsW")
                .HasColumnType("int");

            builder.Property(t => t.IsHr)
                .HasColumnName("IsHr")
                .HasColumnType("int");

            builder.Property(t => t.ThermalEfficiency)
                .HasColumnName("ThermalEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.InputCapacity)
                .HasColumnName("InputCapacity")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsFlueCombined)
                .HasColumnName("IsFlueCombined")
                .HasColumnType("int");

            builder.Property(t => t.FlueDiameter)
                .HasColumnName("FlueDiameter")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsDrainWaterHeatRecovery)
                .HasColumnName("IsDrainWaterHeatRecovery")
                .HasColumnType("int");

            builder.Property(t => t.DWHRManufacturerId)
                .HasColumnName("DWHRManufacturerId")
                .HasColumnType("int");

            builder.Property(t => t.DWHRModelId)
                .HasColumnName("DWHRModelId")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
