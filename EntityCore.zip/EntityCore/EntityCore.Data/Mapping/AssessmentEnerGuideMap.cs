using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentEnerGuideMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentEnerGuide>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentEnerGuide> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentEnerGuide", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsHouseholdOperating)
                .HasColumnName("IsHouseholdOperating")
                .HasColumnType("int");

            builder.Property(t => t.IsEnergyLoads)
                .HasColumnName("IsEnergyLoads")
                .HasColumnType("int");

            builder.Property(t => t.IsWaterConservation)
                .HasColumnName("IsWaterConservation")
                .HasColumnType("int");

            builder.Property(t => t.IsReducedOperating)
                .HasColumnName("IsReducedOperating")
                .HasColumnType("int");

            builder.Property(t => t.VermiculiteId)
                .HasColumnName("VermiculiteId")
                .HasColumnType("int");

            builder.Property(t => t.ObservedBase)
                .HasColumnName("ObservedBase")
                .HasColumnType("int");

            builder.Property(t => t.Recommended)
                .HasColumnName("Recommended")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
