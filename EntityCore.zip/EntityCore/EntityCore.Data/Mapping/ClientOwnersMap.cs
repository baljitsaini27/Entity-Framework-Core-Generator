using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class ClientOwnersMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.ClientOwners>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.ClientOwners> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("ClientOwners", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.ClientId)
                .IsRequired()
                .HasColumnName("ClientId")
                .HasColumnType("bigint");

            builder.Property(t => t.OwnerId)
                .IsRequired()
                .HasColumnName("OwnerId")
                .HasColumnType("bigint");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            builder.HasOne(t => t.Client)
                .WithMany(t => t.ClientOwners)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK_ClientOwners_Client");

            builder.HasOne(t => t.OwnerOwners)
                .WithMany(t => t.OwnerClientOwners)
                .HasForeignKey(d => d.OwnerId)
                .HasConstraintName("FK_ClientOwners_Owners");

            #endregion
        }

    }
}
