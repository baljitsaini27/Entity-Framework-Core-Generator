using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentSpecificationsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentSpecifications>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentSpecifications> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentSpecifications", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.HouseTypeId)
                .IsRequired()
                .HasColumnName("HouseTypeId")
                .HasColumnType("bigint");

            builder.Property(t => t.StoreysId)
                .IsRequired()
                .HasColumnName("StoreysId")
                .HasColumnType("bigint");

            builder.Property(t => t.OrientationId)
                .HasColumnName("OrientationId")
                .HasColumnType("bigint");

            builder.Property(t => t.YearBuiltId)
                .HasColumnName("YearBuiltId")
                .HasColumnType("bigint");

            builder.Property(t => t.Year)
                .HasColumnName("Year")
                .HasColumnType("int");

            builder.Property(t => t.WallColorId)
                .HasColumnName("WallColorId")
                .HasColumnType("bigint");

            builder.Property(t => t.Color)
                .HasColumnName("Color")
                .HasColumnType("varchar(150)")
                .HasMaxLength(150);

            builder.Property(t => t.AboveGrade)
                .HasColumnName("AboveGrade")
                .HasColumnType("int");

            builder.Property(t => t.BelowGrade)
                .HasColumnName("BelowGrade")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
