using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentNaturalSpecMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentNaturalSpec>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentNaturalSpec> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentNaturalSpec", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .IsRequired()
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.HouseVolume)
                .HasColumnName("HouseVolume")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsCrawVolume)
                .HasColumnName("IsCrawVolume")
                .HasColumnType("int");

            builder.Property(t => t.AirTightnessTypeId)
                .HasColumnName("AirTightnessTypeId")
                .HasColumnType("bigint");

            builder.Property(t => t.TerrainId)
                .HasColumnName("TerrainId")
                .HasColumnType("int");

            builder.Property(t => t.AboveGrade)
                .HasColumnName("AboveGrade")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.DepressurizationStatusId)
                .HasColumnName("DepressurizationStatusId")
                .HasColumnType("int");

            builder.Property(t => t.DepressurizationTestResult)
                .HasColumnName("DepressurizationTestResult")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsAirLeakage)
                .HasColumnName("IsAirLeakage")
                .HasColumnType("int");

            builder.Property(t => t.AirChangeRate)
                .HasColumnName("AirChangeRate")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.TestTypeId)
                .HasColumnName("TestTypeId")
                .HasColumnType("int");

            builder.Property(t => t.EquivalentLeakageTypeId)
                .HasColumnName("EquivalentLeakageTypeId")
                .HasColumnType("int");

            builder.Property(t => t.Value)
                .HasColumnName("Value")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ValueAtId)
                .HasColumnName("ValueAtId")
                .HasColumnType("int");

            builder.Property(t => t.WallLocalShieldingId)
                .HasColumnName("WallLocalShieldingId")
                .HasColumnType("int");

            builder.Property(t => t.FlueLocalShieldingId)
                .HasColumnName("FlueLocalShieldingId")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
