using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolRadiantMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolRadiant>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolRadiant> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolRadiant", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.AtticEffectiveTemp)
                .HasColumnName("AtticEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AtticTotalArea)
                .HasColumnName("AtticTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlatRoofEffectiveTemp)
                .HasColumnName("FlatRoofEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlatRoofTotalArea)
                .HasColumnName("FlatRoofTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CrawlSpaceEffectiveTemp)
                .HasColumnName("CrawlSpaceEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CrawlSpaceTotalArea)
                .HasColumnName("CrawlSpaceTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SlabGradeEffectiveTemp)
                .HasColumnName("SlabGradeEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SlabGradeTotalArea)
                .HasColumnName("SlabGradeTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AboveBasementEffectiveTemp)
                .HasColumnName("AboveBasementEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.AboveBasementTotalArea)
                .HasColumnName("AboveBasementTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.BasementEffectiveTemp)
                .HasColumnName("BasementEffectiveTemp")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.BasementTotalArea)
                .HasColumnName("BasementTotalArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
