using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentHeatCoolSupplyHtgMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentHeatCoolSupplyHtg>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentHeatCoolSupplyHtg> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentHeatCoolSupplyHtg", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.HeatingCoolingId)
                .HasColumnName("HeatingCoolingId")
                .HasColumnType("bigint");

            builder.Property(t => t.EnergySourceId)
                .HasColumnName("EnergySourceId")
                .HasColumnType("int");

            builder.Property(t => t.EquipmentType)
                .HasColumnName("EquipmentType")
                .HasColumnType("int");

            builder.Property(t => t.YearMade)
                .HasColumnName("YearMade")
                .HasColumnType("int");

            builder.Property(t => t.Manufacturer)
                .HasColumnName("Manufacturer")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100);

            builder.Property(t => t.Model)
                .HasColumnName("Model")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Description)
                .HasColumnName("Description")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.IsEnergyStar)
                .HasColumnName("IsEnergyStar")
                .HasColumnType("int");

            builder.Property(t => t.IsEPA)
                .HasColumnName("IsEPA")
                .HasColumnType("int");

            builder.Property(t => t.UsageId)
                .HasColumnName("UsageId")
                .HasColumnType("int");

            builder.Property(t => t.LocationHeatedId)
                .HasColumnName("LocationHeatedId")
                .HasColumnType("int");

            builder.Property(t => t.FloorAreaValue)
                .HasColumnName("FloorAreaValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FlueLocationId)
                .HasColumnName("FlueLocationId")
                .HasColumnType("int");

            builder.Property(t => t.FlueTypeId)
                .HasColumnName("FlueTypeId")
                .HasColumnType("int");

            builder.Property(t => t.RatedHeatingCapacity)
                .HasColumnName("RatedHeatingCapacity")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SteadyEfficiency)
                .HasColumnName("SteadyEfficiency")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EnergyConsumption)
                .HasColumnName("EnergyConsumption")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsDamperClosed)
                .HasColumnName("IsDamperClosed")
                .HasColumnType("int");

            builder.Property(t => t.IsDiameter)
                .HasColumnName("IsDiameter")
                .HasColumnType("int");

            builder.Property(t => t.IsArea)
                .HasColumnName("IsArea")
                .HasColumnType("int");

            builder.Property(t => t.DimensionValue)
                .HasColumnName("DimensionValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
