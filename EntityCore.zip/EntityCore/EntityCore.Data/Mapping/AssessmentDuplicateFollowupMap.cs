using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentDuplicateFollowupMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentDuplicateFollowup>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentDuplicateFollowup> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentDuplicateFollowup", "dbo");

            // properties
            builder.Property(t => t.RowNumber)
                .HasColumnName("RowNumber")
                .HasColumnType("int");

            builder.Property(t => t.OldAssessmentCompId)
                .HasColumnName("OldAssessmentCompId")
                .HasColumnType("bigint");

            builder.Property(t => t.NewAssessmentCompId)
                .HasColumnName("NewAssessmentCompId")
                .HasColumnType("bigint");

            // relationships
            #endregion
        }

    }
}
