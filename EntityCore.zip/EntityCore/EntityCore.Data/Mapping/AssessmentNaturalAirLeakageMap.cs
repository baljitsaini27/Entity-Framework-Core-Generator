using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentNaturalAirLeakageMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentNaturalAirLeakage>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentNaturalAirLeakage> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentNaturalAirLeakage", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .IsRequired()
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .IsRequired()
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.IsCGSB)
                .HasColumnName("IsCGSB")
                .HasColumnType("int");

            builder.Property(t => t.IsAsOperated)
                .HasColumnName("IsAsOperated")
                .HasColumnType("int");

            builder.Property(t => t.TestTypeId)
                .HasColumnName("TestTypeId")
                .HasColumnType("int");

            builder.Property(t => t.OutsideTemperature)
                .HasColumnName("OutsideTemperature")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.BarometricPressure)
                .HasColumnName("BarometricPressure")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.HouseVolume)
                .HasColumnName("HouseVolume")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdateBy)
                .HasColumnName("UpdateBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
