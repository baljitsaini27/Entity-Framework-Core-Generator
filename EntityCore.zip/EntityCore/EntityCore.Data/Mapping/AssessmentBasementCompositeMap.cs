using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentBasementCompositeMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentBasementComposite>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentBasementComposite> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentBasementComposite", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.BasementConstructionId)
                .HasColumnName("BasementConstructionId")
                .HasColumnType("bigint");

            builder.Property(t => t.CompositeTypeId)
                .HasColumnName("CompositeTypeId")
                .HasColumnType("int");

            builder.Property(t => t.SectionOneArea)
                .HasColumnName("SectionOneArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SectionOneRSI)
                .HasColumnName("SectionOneRSI")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SectionTwoArea)
                .HasColumnName("SectionTwoArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SectionTwoRSI)
                .HasColumnName("SectionTwoRSI")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SectionThreeArea)
                .HasColumnName("SectionThreeArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.SectionThreeRSI)
                .HasColumnName("SectionThreeRSI")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.RemainderArea)
                .HasColumnName("RemainderArea")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.RemainderRSI)
                .HasColumnName("RemainderRSI")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Total)
                .HasColumnName("Total")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.EffectiveRSI)
                .HasColumnName("EffectiveRSI")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
