using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class UserWeeklyScheduleMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.UserWeeklySchedule>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.UserWeeklySchedule> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("UserWeeklySchedule", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.RecurrenceId)
                .HasColumnName("RecurrenceId")
                .HasColumnType("bigint");

            builder.Property(t => t.UserId)
                .IsRequired()
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.EventType)
                .IsRequired()
                .HasColumnName("EventType")
                .HasColumnType("int");

            builder.Property(t => t.EventName)
                .HasColumnName("EventName")
                .HasColumnType("varchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.EventDescription)
                .HasColumnName("EventDescription")
                .HasColumnType("varchar(max)");

            builder.Property(t => t.StartDate)
                .HasColumnName("StartDate")
                .HasColumnType("datetime");

            builder.Property(t => t.EndDate)
                .HasColumnName("EndDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            builder.Property(t => t.IsExported)
                .IsRequired()
                .HasColumnName("IsExported")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            // relationships
            #endregion
        }

    }
}
