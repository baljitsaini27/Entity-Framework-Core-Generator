using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class PropertyMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.Property>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.Property> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("Property", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.PropertyCode)
                .HasColumnName("PropertyCode")
                .HasColumnType("nvarchar(20)")
                .HasMaxLength(20);

            builder.Property(t => t.Street)
                .HasColumnName("Street")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.City)
                .HasColumnName("City")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Province)
                .HasColumnName("Province")
                .HasColumnType("int");

            builder.Property(t => t.PostalCode)
                .HasColumnName("PostalCode")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Longitude)
                .HasColumnName("Longitude")
                .HasColumnType("decimal(18, 10)");

            builder.Property(t => t.Latitude)
                .HasColumnName("Latitude")
                .HasColumnType("decimal(18, 10)");

            builder.Property(t => t.PropertyTaxRoll)
                .HasColumnName("PropertyTaxRoll")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.BuilderName)
                .HasColumnName("BuilderName")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.OwnerShipType)
                .HasColumnName("OwnerShipType")
                .HasColumnType("int");

            builder.Property(t => t.HouseSize)
                .HasColumnName("HouseSize")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
