using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class BookingSchedularNotesMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.BookingSchedularNotes>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.BookingSchedularNotes> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("BookingSchedularNotes", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.BookingId)
                .IsRequired()
                .HasColumnName("BookingId")
                .HasColumnType("bigint");

            builder.Property(t => t.Description)
                .IsRequired()
                .HasColumnName("Description")
                .HasColumnType("varchar(2000)")
                .HasMaxLength(2000);

            builder.Property(t => t.IsPrivate)
                .IsRequired()
                .HasColumnName("IsPrivate")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .IsRequired()
                .HasColumnName("CreatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CreatedDate)
                .IsRequired()
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
