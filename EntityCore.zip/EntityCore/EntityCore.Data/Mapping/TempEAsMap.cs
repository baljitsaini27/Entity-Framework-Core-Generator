using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class TempEAsMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.TempEAs>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.TempEAs> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("TempEAs", "dbo");

            // properties
            builder.Property(t => t.Id)
                .HasColumnName("Id")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Project)
                .HasColumnName("Project")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Ea)
                .HasColumnName("EA #")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.FirstName)
                .HasColumnName("First Name")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.LastName)
                .HasColumnName("Last Name")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.BusinessPhone)
                .HasColumnName("Business Phone")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CellPhone)
                .HasColumnName("Cell Phone")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.HomePhone)
                .HasColumnName("Home Phone")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.BusinessEmail)
                .HasColumnName("Business Email")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.PersonalEmail)
                .HasColumnName("Personal Email")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CivicNumber)
                .HasColumnName("Civic Number")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Street)
                .HasColumnName("Street")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.City)
                .HasColumnName("City")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Province)
                .HasColumnName("Province")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.PostalCodeFSA)
                .HasColumnName("Postal Code FSA")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.PostalCodeLDU)
                .HasColumnName("Postal Code LDU")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.BusinessName)
                .HasColumnName("Business Name")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Hst)
                .HasColumnName("HST#")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.InitialAuditCost)
                .HasColumnName("Initial Audit Cost ($)")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.FollowUpAuditCost)
                .HasColumnName("Follow-up Audit Cost ($)")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.ContractExpiryDate)
                .HasColumnName("Contract Expiry Date")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.InsuranceExpiryDate)
                .HasColumnName("Insurance Expiry Date")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.EOExpiryDate)
                .HasColumnName("E & O Expiry Date")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.FileType)
                .HasColumnName("File Type")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.File)
                .HasColumnName("File")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.AddedOn)
                .HasColumnName("Added On")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.AddedBy)
                .HasColumnName("Added By")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.EANotesPrivate)
                .HasColumnName("EA Notes-Private")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.NoteCreatedOn)
                .HasColumnName("Note Created On")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CreatedBy)
                .HasColumnName("Created By")
                .HasColumnType("varchar(50)")
                .HasMaxLength(50);

            // relationships
            #endregion
        }

    }
}
