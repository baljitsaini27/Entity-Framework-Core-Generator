using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class AssessmentCrawlSpaceConstructionMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.AssessmentCrawlSpaceConstruction>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.AssessmentCrawlSpaceConstruction> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("AssessmentCrawlSpaceConstruction", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.AssessmentId)
                .HasColumnName("AssessmentId")
                .HasColumnType("bigint");

            builder.Property(t => t.AssessmentComponentId)
                .HasColumnName("AssessmentComponentId")
                .HasColumnType("bigint");

            builder.Property(t => t.TypeId)
                .HasColumnName("TypeId")
                .HasColumnType("int");

            builder.Property(t => t.TypeRValue)
                .HasColumnName("TypeRValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.Corners)
                .HasColumnName("Corners")
                .HasColumnType("int");

            builder.Property(t => t.Skirt)
                .HasColumnName("Skirt")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.ThermalBreak)
                .HasColumnName("ThermalBreak")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.InsulationSlabId)
                .HasColumnName("InsulationSlabId")
                .HasColumnType("int");

            builder.Property(t => t.InsulationRValue)
                .HasColumnName("InsulationRValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.FloorAboveFoundationId)
                .HasColumnName("FloorAboveFoundationId")
                .HasColumnType("int");

            builder.Property(t => t.AboveFoundationRValue)
                .HasColumnName("AboveFoundationRValue")
                .HasColumnType("decimal(18, 2)");

            builder.Property(t => t.IsFloorBelowFrostline)
                .HasColumnName("IsFloorBelowFrostline")
                .HasColumnType("int");

            builder.Property(t => t.IsFloorAboveFrostline)
                .HasColumnName("IsFloorAboveFrostline")
                .HasColumnType("int");

            builder.Property(t => t.IsHeatedFloor)
                .HasColumnName("IsHeatedFloor")
                .HasColumnType("int");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdateDate)
                .HasColumnName("UpdateDate")
                .HasColumnType("datetime");

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            #endregion
        }

    }
}
