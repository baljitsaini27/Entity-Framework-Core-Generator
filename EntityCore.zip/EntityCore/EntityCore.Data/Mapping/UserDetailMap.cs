using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityCore.Data.Mapping
{
    public partial class UserDetailMap
        : IEntityTypeConfiguration<EntityCore.Data.Entities.UserDetail>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<EntityCore.Data.Entities.UserDetail> builder)
        {
            #region Generated Configure
            // table
            builder.ToTable("UserDetail", "dbo");

            // key
            builder.HasKey(t => t.Id);

            // properties
            builder.Property(t => t.Id)
                .IsRequired()
                .HasColumnName("Id")
                .HasColumnType("bigint")
                .ValueGeneratedOnAdd();

            builder.Property(t => t.UserId)
                .IsRequired()
                .HasColumnName("UserId")
                .HasColumnType("bigint");

            builder.Property(t => t.CompanyName)
                .HasColumnName("CompanyName")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.BusinessPhone)
                .HasColumnName("BusinessPhone")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.HomePhone)
                .HasColumnName("HomePhone")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.CellPhone)
                .HasColumnName("CellPhone")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Extension)
                .HasColumnName("Extension")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Street)
                .HasColumnName("Street")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.City)
                .HasColumnName("City")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.Province)
                .HasColumnName("Province")
                .HasColumnType("int");

            builder.Property(t => t.PostalCode)
                .HasColumnName("PostalCode")
                .HasColumnType("nvarchar(50)")
                .HasMaxLength(50);

            builder.Property(t => t.Longitude)
                .HasColumnName("Longitude")
                .HasColumnType("decimal(18, 10)");

            builder.Property(t => t.Latitude)
                .HasColumnName("Latitude")
                .HasColumnType("decimal(18, 10)");

            builder.Property(t => t.AltStreet)
                .HasColumnName("AltStreet")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.AltCity)
                .HasColumnName("AltCity")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.AltProvince)
                .HasColumnName("AltProvince")
                .HasColumnType("int");

            builder.Property(t => t.AltPostalCode)
                .HasColumnName("AltPostalCode")
                .HasColumnType("nvarchar(250)")
                .HasMaxLength(250);

            builder.Property(t => t.IsAutoSaveDcf)
                .HasColumnName("IsAutoSaveDcf")
                .HasColumnType("int");

            builder.Property(t => t.IsSystemSetting)
                .HasColumnName("IsSystemSetting")
                .HasColumnType("int");

            builder.Property(t => t.CreatedDate)
                .HasColumnName("CreatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.CreatedBy)
                .HasColumnName("CreatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.UpdatedDate)
                .HasColumnName("UpdatedDate")
                .HasColumnType("datetime");

            builder.Property(t => t.UpdatedBy)
                .HasColumnName("UpdatedBy")
                .HasColumnType("nvarchar(450)")
                .HasMaxLength(450);

            builder.Property(t => t.Status)
                .IsRequired()
                .HasColumnName("Status")
                .HasColumnType("int");

            // relationships
            builder.HasOne(t => t.UserUsers)
                .WithMany(t => t.UserUserDetails)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_UserDetail_Users");

            #endregion
        }

    }
}
