using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentDoorInfo
    {
        public AssessmentDoorInfo()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long AssessmentComponentId { get; set; }

        public string Name { get; set; }

        public int? IsEnergyStar { get; set; }

        public long? DoorTypeId { get; set; }

        public string DoorType { get; set; }

        public decimal? Width { get; set; }

        public decimal? Height { get; set; }

        public decimal? GrossArea { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
