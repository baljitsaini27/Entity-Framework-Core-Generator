using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentBasementConstruction
    {
        public AssessmentBasementConstruction()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public int? InteriorInsulationId { get; set; }

        public decimal? InsulationRValue { get; set; }

        public int? PonyConstructionId { get; set; }

        public decimal? PonyConstructionRValue { get; set; }

        public int? Corners { get; set; }

        public int? CoreWallTypeId { get; set; }

        public decimal? CoreWallRValue { get; set; }

        public int? ExteriorInsulationId { get; set; }

        public decimal? ExteriorRValue { get; set; }

        public int? InsulationSlabId { get; set; }

        public decimal? InsulationSlabRValue { get; set; }

        public int? FloorAboveFoundationId { get; set; }

        public decimal? AboveFoundationRValue { get; set; }

        public int? IsFloorBelowFrostline { get; set; }

        public int? IsFloorAboveFrostline { get; set; }

        public int? IsHeatedFloor { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        public int InsulationConfigurationId { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
