using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class ElevationTypeTwo
    {
        public ElevationTypeTwo()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public decimal? GableToGable { get; set; }

        public decimal? SloppedCeilingArea { get; set; }

        public decimal? FlatCeilingArea { get; set; }

        public decimal? FloorArea { get; set; }

        public decimal? FloorVolume { get; set; }

        public decimal? FlatCeilingWidth { get; set; }

        public decimal? HeightFromFloor { get; set; }

        public decimal? KneeWallHeight { get; set; }

        public decimal? KneeWallToKneeWall { get; set; }

        public decimal? EaveTroughToEaveTrough { get; set; }

        public decimal? HeaderPerimeter { get; set; }

        public decimal? WallArea { get; set; }

        public decimal? SloppedCeilingLength { get; set; }

        public decimal? GrablePerimeter { get; set; }

        public decimal? KneewallPer { get; set; }

        public decimal? AvGableWallHeight { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public decimal? FlatCeilingBehind { get; set; }

        public decimal? FlatCeilingAbove { get; set; }

        public decimal? AreaGableWalls { get; set; }

        public decimal? AreaKneeWalls { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
