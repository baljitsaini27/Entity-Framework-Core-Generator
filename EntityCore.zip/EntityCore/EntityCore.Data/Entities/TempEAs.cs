using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class TempEAs
    {
        public TempEAs()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public string Id { get; set; }

        public string Project { get; set; }

        public string Ea { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string BusinessPhone { get; set; }

        public string CellPhone { get; set; }

        public string HomePhone { get; set; }

        public string BusinessEmail { get; set; }

        public string PersonalEmail { get; set; }

        public string CivicNumber { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string Province { get; set; }

        public string PostalCodeFSA { get; set; }

        public string PostalCodeLDU { get; set; }

        public string BusinessName { get; set; }

        public string Hst { get; set; }

        public string InitialAuditCost { get; set; }

        public string FollowUpAuditCost { get; set; }

        public string ContractExpiryDate { get; set; }

        public string InsuranceExpiryDate { get; set; }

        public string EOExpiryDate { get; set; }

        public string FileType { get; set; }

        public string File { get; set; }

        public string AddedOn { get; set; }

        public string AddedBy { get; set; }

        public string EANotesPrivate { get; set; }

        public string NoteCreatedOn { get; set; }

        public string CreatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
