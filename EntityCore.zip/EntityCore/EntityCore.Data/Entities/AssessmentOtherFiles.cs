using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentOtherFiles
    {
        public AssessmentOtherFiles()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long ComponentId { get; set; }

        public int TabId { get; set; }

        public int CategoryId { get; set; }

        public int? LabelNumber { get; set; }

        public string FileTitle { get; set; }

        public string FileName { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
