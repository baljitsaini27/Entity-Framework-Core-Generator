using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Province
    {
        public Province()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public int Id { get; set; }

        public string ProvinceName { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
