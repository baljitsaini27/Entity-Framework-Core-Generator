using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolRadiant
    {
        public AssessmentHeatCoolRadiant()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public decimal? AtticEffectiveTemp { get; set; }

        public decimal? AtticTotalArea { get; set; }

        public decimal? FlatRoofEffectiveTemp { get; set; }

        public decimal? FlatRoofTotalArea { get; set; }

        public decimal? CrawlSpaceEffectiveTemp { get; set; }

        public decimal? CrawlSpaceTotalArea { get; set; }

        public decimal? SlabGradeEffectiveTemp { get; set; }

        public decimal? SlabGradeTotalArea { get; set; }

        public decimal? AboveBasementEffectiveTemp { get; set; }

        public decimal? AboveBasementTotalArea { get; set; }

        public decimal? BasementEffectiveTemp { get; set; }

        public decimal? BasementTotalArea { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
