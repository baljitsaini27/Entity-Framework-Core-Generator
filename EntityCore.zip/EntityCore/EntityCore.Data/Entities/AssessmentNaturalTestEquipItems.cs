using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentNaturalTestEquipItems
    {
        public AssessmentNaturalTestEquipItems()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long TestEquipId { get; set; }

        public int? Type { get; set; }

        public int? HsePressureType { get; set; }

        public decimal? HsePressure { get; set; }

        public decimal? FanPressure { get; set; }

        public decimal? MeasuredFlow { get; set; }

        public int? FlowRangeId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
