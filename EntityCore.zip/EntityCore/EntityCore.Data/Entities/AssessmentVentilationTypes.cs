using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentVentilationTypes
    {
        public AssessmentVentilationTypes()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? VentilationId { get; set; }

        public int? VentilatorTypeId { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int? IsEnergyStar { get; set; }

        public int? IsHVI { get; set; }

        public decimal? AirflowRateSupply { get; set; }

        public decimal? Exhaust { get; set; }

        public int? IsDefaultFanPower { get; set; }

        public decimal? FanPower { get; set; }

        public decimal? Condition1Preheater { get; set; }

        public decimal? Condition1Temperature { get; set; }

        public decimal? Condition1Effciency { get; set; }

        public decimal? Condition2Preheater { get; set; }

        public decimal? Condition2Temperature { get; set; }

        public decimal? Condition2Effciency { get; set; }

        public decimal? PreHeaterCapacity { get; set; }

        public decimal? LowTempVentilation { get; set; }

        public decimal? CoolingEfficiency { get; set; }

        public int? Type { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
