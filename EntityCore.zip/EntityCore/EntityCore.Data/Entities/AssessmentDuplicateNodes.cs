using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentDuplicateNodes
    {
        public AssessmentDuplicateNodes()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public int? RowNumber { get; set; }

        public long? Id { get; set; }

        public long? ParentId { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
