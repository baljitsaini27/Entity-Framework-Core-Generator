using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentBasementComposite
    {
        public AssessmentBasementComposite()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? BasementConstructionId { get; set; }

        public int? CompositeTypeId { get; set; }

        public decimal? SectionOneArea { get; set; }

        public decimal? SectionOneRSI { get; set; }

        public decimal? SectionTwoArea { get; set; }

        public decimal? SectionTwoRSI { get; set; }

        public decimal? SectionThreeArea { get; set; }

        public decimal? SectionThreeRSI { get; set; }

        public decimal? RemainderArea { get; set; }

        public decimal? RemainderRSI { get; set; }

        public decimal? Total { get; set; }

        public decimal? EffectiveRSI { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
