using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Assessment
    {
        public Assessment()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? ReferanceId { get; set; }

        public string AssessmentNumber { get; set; }

        public string PrevAssessmentNumber { get; set; }

        public int? IsVentilationSystem { get; set; }

        public int? IsDomesticHotWater { get; set; }

        public int? Type { get; set; }

        public DateTime? EvalutionDate { get; set; }

        public DateTime? SubmittedDate { get; set; }

        public long? PropertyId { get; set; }

        public long UserId { get; set; }

        public long CompanyId { get; set; }

        public string BatchNumber { get; set; }

        public string SuggestEditNotes { get; set; }

        public string FileRejectedNotes { get; set; }

        public int IsLatest { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public long? BookingId { get; set; }

        public int IsElectronicDcf { get; set; }

        public long? ImportAssessmentId { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
