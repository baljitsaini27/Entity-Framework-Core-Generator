using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentVentilation
    {
        public AssessmentVentilation()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long AssessmentComponentId { get; set; }

        public int? CirculationTypeId { get; set; }

        public int? VentilatorTypeId { get; set; }

        public decimal? SupplyFlowRate { get; set; }

        public decimal? ExhaustFlowRate { get; set; }

        public int? ComponentTypeId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
