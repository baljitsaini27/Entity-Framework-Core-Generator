using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Notifications
    {
        public Notifications()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? UserId { get; set; }

        public string UserName { get; set; }

        public string ModuleName { get; set; }

        public long? ModuleId { get; set; }

        public string Description { get; set; }

        public string SubInfo1 { get; set; }

        public string SubInfo2 { get; set; }

        public string SubInfo3 { get; set; }

        public int? IsNotify { get; set; }

        public int? IsRead { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
