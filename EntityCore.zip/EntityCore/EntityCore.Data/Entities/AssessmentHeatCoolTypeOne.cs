using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolTypeOne
    {
        public AssessmentHeatCoolTypeOne()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public int? TabType { get; set; }

        public int? EnergySourceId { get; set; }

        public int? IsDueFuel { get; set; }

        public decimal? SwitchOverTemp { get; set; }

        public int? EquipmentType { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int? IsEnergyStar { get; set; }

        public int? IsEPA { get; set; }

        public int? OutputCapacity { get; set; }

        public decimal? Value { get; set; }

        public decimal? SizingFactor { get; set; }

        public decimal? Efficiency { get; set; }

        public int? IsSteadyState { get; set; }

        public int? IsAFUE { get; set; }

        public decimal? PilotLight { get; set; }

        public decimal? FlueDiameter { get; set; }

        public int? TankVolumeId { get; set; }

        public decimal? TankVolume { get; set; }

        public int? EnergyFactorId { get; set; }

        public decimal? EnergyFactor { get; set; }

        public int? TankLocationId { get; set; }

        public int? CirculationPumpId { get; set; }

        public decimal? CirculationPumpValue { get; set; }

        public int? IsEnergyPumpMotor { get; set; }

        public int? IsDrainWaterHeat { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
