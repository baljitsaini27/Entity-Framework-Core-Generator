using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentGenerationPhotoVoltaic
    {
        public AssessmentGenerationPhotoVoltaic()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long GenerationId { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public decimal? ArrayArea { get; set; }

        public decimal? Slope { get; set; }

        public decimal? Azimuth { get; set; }

        public decimal? ModuleEfficiency { get; set; }

        public decimal? CellTemp { get; set; }

        public decimal? TempCoefficient { get; set; }

        public decimal? ArrayLosses { get; set; }

        public decimal? ConditioningLosses { get; set; }

        public decimal? InverterEfficiency { get; set; }

        public decimal? GridRate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
