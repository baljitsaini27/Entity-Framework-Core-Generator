using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserWeeklySchedule
    {
        public UserWeeklySchedule()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? RecurrenceId { get; set; }

        public long UserId { get; set; }

        public int EventType { get; set; }

        public string EventName { get; set; }

        public string EventDescription { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int Status { get; set; }

        public int IsExported { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
