using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class BookingEventSeries
    {
        public BookingEventSeries()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long UserId { get; set; }

        public int? Occurrences { get; set; }

        public int? ReOccurrenceType { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int? RecurrEvery { get; set; }

        public int? DailyType { get; set; }

        public string WeekDays { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
