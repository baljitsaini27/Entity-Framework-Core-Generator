using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolTypeTwo
    {
        public AssessmentHeatCoolTypeTwo()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public int? TabType { get; set; }

        public int? UnitFunctionId { get; set; }

        public int? CentralEquipmentTypeId { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int? IsEnergyStar { get; set; }

        public int? OutputCapacity { get; set; }

        public decimal? Capacity { get; set; }

        public decimal? Efficiency { get; set; }

        public decimal? HeatingEfficiency { get; set; }

        public decimal? CoolingEfficiency { get; set; }

        public int? IsHeatCOP { get; set; }

        public int? IsHSPF { get; set; }

        public int? IsCoolCOP { get; set; }

        public int? IsSEER { get; set; }

        public int? TempCutoffId { get; set; }

        public decimal? TempCutoff { get; set; }

        public int? TempRatingType { get; set; }

        public decimal? RatingTemp { get; set; }

        public decimal? CrankcaseHeater { get; set; }

        public decimal? SensibleHeatRadio { get; set; }

        public decimal? OpenableWindowArea { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
