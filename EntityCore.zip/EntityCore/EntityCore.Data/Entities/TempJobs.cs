using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class TempJobs
    {
        public TempJobs()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public string Project { get; set; }

        public string Id { get; set; }

        public string AboutUs { get; set; }

        public string Ea { get; set; }

        public string Customer { get; set; }

        public string Followup { get; set; }

        public string JobNumber { get; set; }

        public string JobType { get; set; }

        public string EnergyProgram { get; set; }

        public string CivicNnumber { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string Provice { get; set; }

        public string Postal1 { get; set; }

        public string Postal2 { get; set; }

        public string Fee { get; set; }

        public string PaymentMethod { get; set; }

        public string Cheque { get; set; }

        public string QBrevenue { get; set; }

        public string QBCost { get; set; }

        public string Appointment { get; set; }

        public string Month { get; set; }

        public string NumberOfJob { get; set; }

        public string EleFiles { get; set; }

        public string FileUploadDB { get; set; }

        public string FileAcceptNRCan { get; set; }

        public string NRCanBatch { get; set; }

        public string JobStatus { get; set; }

        public string FormReceive { get; set; }

        public string FormSentNRCan { get; set; }

        public string ReportSent { get; set; }

        public string FileAuditDate { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
