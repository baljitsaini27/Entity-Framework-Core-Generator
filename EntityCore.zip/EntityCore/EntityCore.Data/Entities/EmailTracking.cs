using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class EmailTracking
    {
        public EmailTracking()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        public string TrackingId { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
