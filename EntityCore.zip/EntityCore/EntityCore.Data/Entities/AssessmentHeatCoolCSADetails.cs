using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolCSADetails
    {
        public AssessmentHeatCoolCSADetails()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolCSAId { get; set; }

        public long? ManufacturerId { get; set; }

        public long? ModelId { get; set; }

        public int? EnergySourceId { get; set; }

        public decimal? NetEfficiency1 { get; set; }

        public decimal? NetEfficiency2 { get; set; }

        public decimal? NetEfficiency3 { get; set; }

        public decimal? AverageElectrical1 { get; set; }

        public decimal? AverageElectrical2 { get; set; }

        public decimal? AverageElectrical3 { get; set; }

        public decimal? MotorPower1 { get; set; }

        public decimal? MotorPower2 { get; set; }

        public decimal? MotorPower3 { get; set; }

        public decimal? Pcont { get; set; }

        public decimal? Pcirc { get; set; }

        public decimal? DailyElectricityUse { get; set; }

        public decimal? FanOn { get; set; }

        public decimal? FanOff { get; set; }

        public decimal? DHWonly { get; set; }

        public decimal? SHload { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
