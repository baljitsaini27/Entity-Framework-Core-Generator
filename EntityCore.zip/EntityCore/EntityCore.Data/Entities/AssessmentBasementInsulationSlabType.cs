using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentBasementInsulationSlabType
    {
        public AssessmentBasementInsulationSlabType()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string Name { get; set; }

        public string InternalCode { get; set; }

        public long? FramingId { get; set; }

        public long? SpacingId { get; set; }

        public long? InsulationId { get; set; }

        public long? InteriorFinishId { get; set; }

        public long? InteriorId { get; set; }

        public long? SheathingId { get; set; }

        public int? IsDefault { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
