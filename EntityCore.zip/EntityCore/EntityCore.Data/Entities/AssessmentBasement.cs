using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentBasement
    {
        public AssessmentBasement()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public string Name { get; set; }

        public int? FoundationRoomTypeId { get; set; }

        public int? UpStairsId { get; set; }

        public decimal? Value { get; set; }

        public int? IsRectangular { get; set; }

        public int? IsNonRectangular { get; set; }

        public decimal? Length { get; set; }

        public decimal? Width { get; set; }

        public decimal? Perimeter { get; set; }

        public decimal? TotalArea { get; set; }

        public decimal? TotalWallHeight { get; set; }

        public decimal? DepthBelowGrade { get; set; }

        public int? IsPonyWall { get; set; }

        public decimal? Height { get; set; }

        public decimal? ExposedSurfacesPerimeter { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
