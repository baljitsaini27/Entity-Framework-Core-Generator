using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserDetail
    {
        public UserDetail()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long UserId { get; set; }

        public string CompanyName { get; set; }

        public string BusinessPhone { get; set; }

        public string HomePhone { get; set; }

        public string CellPhone { get; set; }

        public string Extension { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public int? Province { get; set; }

        public string PostalCode { get; set; }

        public decimal? Longitude { get; set; }

        public decimal? Latitude { get; set; }

        public string AltStreet { get; set; }

        public string AltCity { get; set; }

        public int? AltProvince { get; set; }

        public string AltPostalCode { get; set; }

        public int? IsAutoSaveDcf { get; set; }

        public int? IsSystemSetting { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual Users UserUsers { get; set; }

        #endregion

    }
}
