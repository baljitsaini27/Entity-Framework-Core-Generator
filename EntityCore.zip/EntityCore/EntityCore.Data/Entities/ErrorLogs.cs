using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class ErrorLogs
    {
        public ErrorLogs()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string ErrorNumber { get; set; }

        public string ErrorSeverity { get; set; }

        public string ErrorState { get; set; }

        public string ErrorProcedure { get; set; }

        public string ErrorLine { get; set; }

        public string ErrorMessage { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
