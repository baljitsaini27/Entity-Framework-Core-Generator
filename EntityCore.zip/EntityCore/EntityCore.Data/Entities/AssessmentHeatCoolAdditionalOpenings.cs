using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolAdditionalOpenings
    {
        public AssessmentHeatCoolAdditionalOpenings()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public int? EquimentTypeOneId { get; set; }

        public int? EquimentTypeTwoId { get; set; }

        public int? EquimentTypeThreeId { get; set; }

        public decimal? FlueDiameterOne { get; set; }

        public decimal? FlueDiameterTwo { get; set; }

        public decimal? FlueDiameterThree { get; set; }

        public int? IsDamperClosedOne { get; set; }

        public int? IsDamperClosedTwo { get; set; }

        public int? IsDamperClosedThree { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
