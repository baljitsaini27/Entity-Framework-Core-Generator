using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentEnerGuide
    {
        public AssessmentEnerGuide()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public int? IsHouseholdOperating { get; set; }

        public int? IsEnergyLoads { get; set; }

        public int? IsWaterConservation { get; set; }

        public int? IsReducedOperating { get; set; }

        public int? VermiculiteId { get; set; }

        public int? ObservedBase { get; set; }

        public int? Recommended { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
