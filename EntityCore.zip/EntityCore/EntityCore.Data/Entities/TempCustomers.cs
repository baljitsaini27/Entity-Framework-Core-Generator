using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class TempCustomers
    {
        public TempCustomers()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public string Project { get; set; }

        public string Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public string CivicNumber { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string Province { get; set; }

        public string PostalCodeFSA { get; set; }

        public string PostalCodeLDU { get; set; }

        public string CustomerNote { get; set; }

        public string CreatedOn { get; set; }

        public string CreatedBy { get; set; }

        public string File { get; set; }

        public string AddedOn { get; set; }

        public string AddedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
