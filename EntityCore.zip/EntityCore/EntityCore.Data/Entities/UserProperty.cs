using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserProperty
    {
        public UserProperty()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long PropertyId { get; set; }

        public string UserId { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual Property Property { get; set; }

        #endregion

    }
}
