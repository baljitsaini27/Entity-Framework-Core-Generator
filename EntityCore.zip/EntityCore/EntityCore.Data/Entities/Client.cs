using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Client
    {
        public Client()
        {
            #region Generated Constructor
            ClientOwners = new HashSet<ClientOwners>();
            ClientProperties = new HashSet<ClientProperty>();
            UserClients = new HashSet<UserClient>();
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string ClientCode { get; set; }

        public int ClientType { get; set; }

        public long CompanyId { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int? IsExcludeFromSearch { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual ICollection<ClientOwners> ClientOwners { get; set; }

        public virtual ICollection<ClientProperty> ClientProperties { get; set; }

        public virtual ICollection<UserClient> UserClients { get; set; }

        #endregion

    }
}
