using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentWindowType
    {
        public AssessmentWindowType()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public string Name { get; set; }

        public long? GlazingTypeId { get; set; }

        public long? CoatingTintsId { get; set; }

        public long? FillTypeId { get; set; }

        public long? SpacerTypeId { get; set; }

        public long? WindowTypeId { get; set; }

        public long? FrameMaterialId { get; set; }

        public int? IsDefault { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
