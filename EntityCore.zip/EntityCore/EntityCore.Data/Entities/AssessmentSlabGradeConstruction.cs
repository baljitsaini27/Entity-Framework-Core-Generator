using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentSlabGradeConstruction
    {
        public AssessmentSlabGradeConstruction()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public decimal? SkirtRValue { get; set; }

        public decimal? ThermalBreakRValue { get; set; }

        public int? InsulationSlabId { get; set; }

        public decimal? InsulationSlabRValue { get; set; }

        public int? IsFloorBelowFrostline { get; set; }

        public int? IsFloorAboveFrostline { get; set; }

        public int? IsHeatedFloor { get; set; }

        public int? IntegralFooting { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
