using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class EmailTrackingBounced
    {
        public EmailTrackingBounced()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public string Bcc { get; set; }

        public string Cc { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public string TextBody { get; set; }

        public DateTime? SentDate { get; set; }

        public string MessageUid { get; set; }

        public string BuywiseTrackingId { get; set; }

        public string ReasonToFailed { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
