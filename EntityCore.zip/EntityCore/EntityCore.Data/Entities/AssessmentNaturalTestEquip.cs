using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentNaturalTestEquip
    {
        public AssessmentNaturalTestEquip()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long NaturalAirLeakageId { get; set; }

        public int? FanTypeId { get; set; }

        public int? OldFanTypeId { get; set; }

        public string Manometer { get; set; }

        public int? IsBaseLine { get; set; }

        public decimal? InitialPressure { get; set; }

        public decimal? FinalPressure { get; set; }

        public decimal? InsideTemperature { get; set; }

        public decimal? ZoneHeatedVol { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
