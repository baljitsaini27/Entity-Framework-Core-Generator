using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class QaAssessmentRecord
    {
        public QaAssessmentRecord()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long UserId { get; set; }

        public int IsFileSentForQa { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
