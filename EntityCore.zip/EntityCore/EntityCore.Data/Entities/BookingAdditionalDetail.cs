using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class BookingAdditionalDetail
    {
        public BookingAdditionalDetail()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long BookingId { get; set; }

        public int? HouseTypeId { get; set; }

        public int? StoreysId { get; set; }

        public int? YearBuiltId { get; set; }

        public int? Year { get; set; }

        public decimal? HouseSize { get; set; }

        public int? IsBasementInsulation { get; set; }

        public int? IsCrawlspaceInsulation { get; set; }

        public int? IsMainWallInsulation { get; set; }

        public int? IsAtticInsulation { get; set; }

        public int? IsAttic { get; set; }

        public int? IsCrawlspace { get; set; }

        public int? IsCleaned { get; set; }

        public int? WoodBurningAppliances { get; set; }

        public decimal? QuotedPrice { get; set; }

        public int? Windows { get; set; }

        public int? Doors { get; set; }

        public int? SkyLights { get; set; }

        public int? HeatingSystem { get; set; }

        public int? CoolingSystem { get; set; }

        public int? HotWater { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int Status { get; set; }

        public int? IsMainHeatingSystem { get; set; }

        public int? IsAirConditioning { get; set; }

        public int? IsDomesticHotWater { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
