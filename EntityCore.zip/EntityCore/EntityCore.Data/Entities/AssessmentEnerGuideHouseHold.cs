using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentEnerGuideHouseHold
    {
        public AssessmentEnerGuideHouseHold()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? EnerGuideId { get; set; }

        public int? NumberOfOccupants { get; set; }

        public int? IsEnergyStar { get; set; }

        public decimal? DayTime { get; set; }

        public decimal? NightTime { get; set; }

        public decimal? CoolingSeason { get; set; }

        public int? IsLEDBulbs { get; set; }

        public int? IsYearOld { get; set; }

        public int? CoolingSeasonMonth { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
