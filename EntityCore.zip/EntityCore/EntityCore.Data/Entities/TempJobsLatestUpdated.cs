using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class TempJobsLatestUpdated
    {
        public TempJobsLatestUpdated()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long? Propertyid { get; set; }

        public long? Userid { get; set; }

        public string Project { get; set; }

        public string Id { get; set; }

        public string AboutUs { get; set; }

        public string Ea { get; set; }

        public string Customer { get; set; }

        public string Followup { get; set; }

        public string JobNumber { get; set; }

        public string JobType { get; set; }

        public string EnergyProgram { get; set; }

        public string CivicNnumber { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string Provice { get; set; }

        public string Postal1 { get; set; }

        public string Postal2 { get; set; }

        public string Fee { get; set; }

        public string PaymentMethod { get; set; }

        public string Cheque { get; set; }

        public DateTime? QBrevenue { get; set; }

        public DateTime? QBCost { get; set; }

        public string Appointment { get; set; }

        public string Month { get; set; }

        public string NumberOfJob { get; set; }

        public DateTime? EleFiles { get; set; }

        public DateTime? FileUploadDB { get; set; }

        public DateTime? FileAcceptNRCan { get; set; }

        public string NRCanBatch { get; set; }

        public string JobStatus { get; set; }

        public DateTime? FormReceive { get; set; }

        public DateTime? FormSentNRCan { get; set; }

        public DateTime? ReportSent { get; set; }

        public DateTime? FileAuditDate { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
