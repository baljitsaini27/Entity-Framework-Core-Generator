using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentSketch
    {
        public AssessmentSketch()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public int Version { get; set; }

        public string SvgFileName { get; set; }

        public string ImageFileName { get; set; }

        public string SketchName { get; set; }

        public int Status { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
