using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class ClientOwners
    {
        public ClientOwners()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long ClientId { get; set; }

        public long OwnerId { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public string UpdatedBy { get; set; }

        public int? Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual Client Client { get; set; }

        public virtual Owners OwnerOwners { get; set; }

        #endregion

    }
}
