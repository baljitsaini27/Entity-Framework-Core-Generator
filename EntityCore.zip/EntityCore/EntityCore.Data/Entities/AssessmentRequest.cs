using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentRequest
    {
        public AssessmentRequest()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long UserId { get; set; }

        public long AssessmentId { get; set; }

        public int? RequestType { get; set; }

        public string RequestNote { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdateBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
