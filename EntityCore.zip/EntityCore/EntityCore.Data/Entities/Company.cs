using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Company
    {
        public Company()
        {
            #region Generated Constructor
            OrganisationSettings = new HashSet<OrganisationSettings>();
            Users = new HashSet<Users>();
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string CompanyCode { get; set; }

        public string Name { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int? Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual ICollection<OrganisationSettings> OrganisationSettings { get; set; }

        public virtual ICollection<Users> Users { get; set; }

        #endregion

    }
}
