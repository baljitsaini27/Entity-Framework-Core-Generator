using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentCrawlSpace
    {
        public AssessmentCrawlSpace()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public string Name { get; set; }

        public int? CrawlSpaceTypeId { get; set; }

        public int? IsRectangular { get; set; }

        public int? IsNonRectangular { get; set; }

        public decimal? Length { get; set; }

        public decimal? Width { get; set; }

        public decimal? Perimeter { get; set; }

        public decimal? TotalArea { get; set; }

        public decimal? TotalWallHeight { get; set; }

        public decimal? DepthBelowGrade { get; set; }

        public decimal? ExposedSurfacesPerimeter { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
