using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentEnerGuideAtypical
    {
        public AssessmentEnerGuideAtypical()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? EnerGuideId { get; set; }

        public int? IsDeicingCables { get; set; }

        public int? IsElectricVehicle { get; set; }

        public int? IsExtensiveExterior { get; set; }

        public int? IsHeatedGarage { get; set; }

        public int? IsHotTub { get; set; }

        public int? IsMixedUse { get; set; }

        public int? IsOutdoorGas { get; set; }

        public int? IsSwimmingPool { get; set; }

        public int? IsRoomAC { get; set; }

        public int? CountOfUnits { get; set; }

        public int? CountOfEnergyStar { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
