using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolCSA
    {
        public AssessmentHeatCoolCSA()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public long? ManufacturerId { get; set; }

        public long? ModelId { get; set; }

        public int? NumberOfP9 { get; set; }

        public decimal? ThermalPerformanceFactor { get; set; }

        public decimal? ElectricalConsumption { get; set; }

        public decimal? HeatingCapacity { get; set; }

        public decimal? HeatingEfficiency { get; set; }

        public decimal? WaterPerformanceFactor { get; set; }

        public decimal? NormalBurnerInput { get; set; }

        public decimal? RecoveryEfficiency { get; set; }

        public int? IsDrainWaterHeat { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
