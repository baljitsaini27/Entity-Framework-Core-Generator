using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentEnerGuideReducedOperating
    {
        public AssessmentEnerGuideReducedOperating()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? EnerGuideId { get; set; }

        public int? LightingId { get; set; }

        public decimal? ClothesDryer { get; set; }

        public decimal? ClothesWasher { get; set; }

        public decimal? DishWasher { get; set; }

        public decimal? Refrigerator { get; set; }

        public decimal? Range { get; set; }

        public int? IsClothWasherEnergyStar { get; set; }

        public int? IsDishWasherEnergyStar { get; set; }

        public int? IsBathroomFaucets { get; set; }

        public int? IsShowerHeads { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
