using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentHeatCoolSupplyHtg
    {
        public AssessmentHeatCoolSupplyHtg()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? HeatingCoolingId { get; set; }

        public int? EnergySourceId { get; set; }

        public int? EquipmentType { get; set; }

        public int? YearMade { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public string Description { get; set; }

        public int? IsEnergyStar { get; set; }

        public int? IsEPA { get; set; }

        public int? UsageId { get; set; }

        public int? LocationHeatedId { get; set; }

        public decimal? FloorAreaValue { get; set; }

        public int? FlueLocationId { get; set; }

        public int? FlueTypeId { get; set; }

        public decimal? RatedHeatingCapacity { get; set; }

        public decimal? SteadyEfficiency { get; set; }

        public decimal? EnergyConsumption { get; set; }

        public int? IsDamperClosed { get; set; }

        public int? IsDiameter { get; set; }

        public int? IsArea { get; set; }

        public decimal? DimensionValue { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
