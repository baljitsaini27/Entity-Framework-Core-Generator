using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Owners
    {
        public Owners()
        {
            #region Generated Constructor
            OwnerClientOwners = new HashSet<ClientOwners>();
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string BusinessName { get; set; }

        public string BusinessPhone { get; set; }

        public string BusinessEmail { get; set; }

        public int OwnerType { get; set; }

        public string Role { get; set; }

        public string Phone { get; set; }

        public string Mobile { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public int? Province { get; set; }

        public string PostalCode { get; set; }

        public string Extension { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        public int? TimeZone { get; set; }

        #endregion

        #region Generated Relationships
        public virtual ICollection<ClientOwners> OwnerClientOwners { get; set; }

        #endregion

    }
}
