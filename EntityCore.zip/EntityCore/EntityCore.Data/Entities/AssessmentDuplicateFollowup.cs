using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentDuplicateFollowup
    {
        public AssessmentDuplicateFollowup()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public int? RowNumber { get; set; }

        public long? OldAssessmentCompId { get; set; }

        public long? NewAssessmentCompId { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
