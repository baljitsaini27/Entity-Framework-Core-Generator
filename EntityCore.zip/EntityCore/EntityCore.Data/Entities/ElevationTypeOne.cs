using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class ElevationTypeOne
    {
        public ElevationTypeOne()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public string Location { get; set; }

        public decimal? GableEnds { get; set; }

        public decimal? GableToGableLeft { get; set; }

        public decimal? SloppedCeilingArea { get; set; }

        public decimal? HeightLeft { get; set; }

        public decimal? HeightRight { get; set; }

        public decimal? AverageHeightLeft { get; set; }

        public decimal? AverageHeightRight { get; set; }

        public decimal? BaseLeftSide { get; set; }

        public decimal? BaseRightSide { get; set; }

        public decimal? ModifiedPerimeter { get; set; }

        public decimal? ModifiedHeight { get; set; }

        public decimal? GableToGableRight { get; set; }

        public decimal? VolumeUnderSloppedCeiling { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public decimal? FloorArea { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
