using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentSpecifications
    {
        public AssessmentSpecifications()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long HouseTypeId { get; set; }

        public long StoreysId { get; set; }

        public long? OrientationId { get; set; }

        public long? YearBuiltId { get; set; }

        public int? Year { get; set; }

        public long? WallColorId { get; set; }

        public string Color { get; set; }

        public int? AboveGrade { get; set; }

        public int? BelowGrade { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
