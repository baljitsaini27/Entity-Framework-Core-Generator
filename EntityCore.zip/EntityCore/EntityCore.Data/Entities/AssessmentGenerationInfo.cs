using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentGenerationInfo
    {
        public AssessmentGenerationInfo()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long AssessmentComponentId { get; set; }

        public int PhotovoltaicSystem { get; set; }

        public int IsWindEnergy { get; set; }

        public decimal? ValueKWH { get; set; }

        public int IsSolarReady { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
