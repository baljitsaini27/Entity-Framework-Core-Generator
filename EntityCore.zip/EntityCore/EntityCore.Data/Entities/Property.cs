using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Property
    {
        public Property()
        {
            #region Generated Constructor
            ClientProperties = new HashSet<ClientProperty>();
            UserProperties = new HashSet<UserProperty>();
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string PropertyCode { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public int? Province { get; set; }

        public string PostalCode { get; set; }

        public decimal? Longitude { get; set; }

        public decimal? Latitude { get; set; }

        public string PropertyTaxRoll { get; set; }

        public string BuilderName { get; set; }

        public int? OwnerShipType { get; set; }

        public decimal? HouseSize { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        public virtual ICollection<ClientProperty> ClientProperties { get; set; }

        public virtual ICollection<UserProperty> UserProperties { get; set; }

        #endregion

    }
}
