using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentDHW
    {
        public AssessmentDHW()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? AssessmentId { get; set; }

        public long? AssessmentComponentId { get; set; }

        public int? DHWType { get; set; }

        public int? EnergySourceId { get; set; }

        public int? TankTypeId { get; set; }

        public int? TankVolumeId { get; set; }

        public decimal? TankVolume { get; set; }

        public int? EnergyFactorId { get; set; }

        public decimal? EnergyFactor { get; set; }

        public int? TankLocationId { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int? IsEnergyStar { get; set; }

        public int? IsEcoEnergy { get; set; }

        public decimal? InsulatingBlanket { get; set; }

        public decimal? Hpcop { get; set; }

        public decimal? StandByHeatLoss { get; set; }

        public int? IsW { get; set; }

        public int? IsHr { get; set; }

        public decimal? ThermalEfficiency { get; set; }

        public decimal? InputCapacity { get; set; }

        public int? IsFlueCombined { get; set; }

        public decimal? FlueDiameter { get; set; }

        public int? IsDrainWaterHeatRecovery { get; set; }

        public int? DWHRManufacturerId { get; set; }

        public int? DWHRModelId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
