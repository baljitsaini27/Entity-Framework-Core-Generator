using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class Users
    {
        public Users()
        {
            #region Generated Constructor
            UserUserDetails = new HashSet<UserDetail>();
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string Code { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Image { get; set; }

        public long CompanyId { get; set; }

        public string AspNetUserId { get; set; }

        public int UserType { get; set; }

        public int IsEnergyAdvisor { get; set; }

        public int IsQa { get; set; }

        public int? IsExclude { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        public int IsSchedular { get; set; }

        public int IsElectronicDcf { get; set; }

        public int? TimeZone { get; set; }

        public int? IsWifiUploadEnabled { get; set; }

        public string GoogleMail { get; set; }

        public string AssessmentSeries { get; set; }

        public string LastAssessmentNumber { get; set; }

        #endregion

        #region Generated Relationships
        public virtual AspNetUsers AspNetUserAspNetUsers { get; set; }

        public virtual Company Company { get; set; }

        public virtual ICollection<UserDetail> UserUserDetails { get; set; }

        #endregion

    }
}
