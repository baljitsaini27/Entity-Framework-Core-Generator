using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentTemperatureInfo
    {
        public AssessmentTemperatureInfo()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long AssessmentComponentId { get; set; }

        public int BasementIsHeated { get; set; }

        public int BasementIsCooled { get; set; }

        public int IsSeparateThermostat { get; set; }

        public int CrawlSpaceIsHeated { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
