using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentNaturalSpec
    {
        public AssessmentNaturalSpec()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public long AssessmentComponentId { get; set; }

        public decimal? HouseVolume { get; set; }

        public int? IsCrawVolume { get; set; }

        public long? AirTightnessTypeId { get; set; }

        public int? TerrainId { get; set; }

        public decimal? AboveGrade { get; set; }

        public int? DepressurizationStatusId { get; set; }

        public decimal? DepressurizationTestResult { get; set; }

        public int? IsAirLeakage { get; set; }

        public decimal? AirChangeRate { get; set; }

        public int? TestTypeId { get; set; }

        public int? EquivalentLeakageTypeId { get; set; }

        public decimal? Value { get; set; }

        public int? ValueAtId { get; set; }

        public int? WallLocalShieldingId { get; set; }

        public int? FlueLocalShieldingId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
