using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class AssessmentComponent
    {
        public AssessmentComponent()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long ParentId { get; set; }

        public long AssessmentId { get; set; }

        public long ComponentId { get; set; }

        public string ComponentName { get; set; }

        public string AlternateName { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
