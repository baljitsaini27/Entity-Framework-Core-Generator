using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserBooking
    {
        public UserBooking()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? EventId { get; set; }

        public long? PropertyId { get; set; }

        public decimal? Cost { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public string BookingType { get; set; }

        public int? AssessmentType { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
