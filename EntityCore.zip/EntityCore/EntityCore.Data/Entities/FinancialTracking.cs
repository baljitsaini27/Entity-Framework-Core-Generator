using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class FinancialTracking
    {
        public FinancialTracking()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long AssessmentId { get; set; }

        public int? PaymentFor { get; set; }

        public int? PaymentMethod { get; set; }

        public int? CardType { get; set; }

        public string ReceiptName { get; set; }

        public string ReferenceNumber { get; set; }

        public DateTime? PaymentDate { get; set; }

        public decimal? Amount { get; set; }

        public int? IsRevenueEntered { get; set; }

        public DateTime? RevenueEntryDate { get; set; }

        public int? IsCostEntered { get; set; }

        public DateTime? CostEntryDate { get; set; }

        public int? IsUnionGas { get; set; }

        public int? IsEnbridge { get; set; }

        public int? IsIeso { get; set; }

        public int? IsOntario { get; set; }

        public int? HeatingSourceId { get; set; }

        public int? JobTrackingNrcan { get; set; }

        public DateTime? JobTrackingNrcanDate { get; set; }

        public int? JobTrackingSo { get; set; }

        public DateTime? JobTrackingSoDate { get; set; }

        public int? JobTrackingElectronic { get; set; }

        public DateTime? JobTrackingElectronicDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public int Status { get; set; }

        public long? RevenueEntryById { get; set; }

        public long? CostEntryById { get; set; }

        public long? JobTrackingElectronicById { get; set; }

        public long? JobTrackingNrcanById { get; set; }

        public long? JobTrackingSoById { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
