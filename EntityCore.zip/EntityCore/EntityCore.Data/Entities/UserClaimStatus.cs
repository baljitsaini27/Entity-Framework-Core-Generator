using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserClaimStatus
    {
        public UserClaimStatus()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string AspNetUserId { get; set; }

        public int Flag { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
