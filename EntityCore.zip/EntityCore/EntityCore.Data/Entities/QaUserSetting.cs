using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class QaUserSetting
    {
        public QaUserSetting()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long UserId { get; set; }

        public decimal Percentage { get; set; }

        public int StartNumber { get; set; }

        public int EndNumber { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public int Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
