using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class HistoryLogs
    {
        public HistoryLogs()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public string EventName { get; set; }

        public string EventDescription { get; set; }

        public long CreatedFor { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
