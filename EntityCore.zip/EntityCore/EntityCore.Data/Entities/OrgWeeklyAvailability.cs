using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class OrgWeeklyAvailability
    {
        public OrgWeeklyAvailability()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long CompanyId { get; set; }

        public int Weekday { get; set; }

        public int EventType { get; set; }

        public string EventName { get; set; }

        public string EventDescription { get; set; }

        public TimeSpan? StartTime { get; set; }

        public TimeSpan? EndTime { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
