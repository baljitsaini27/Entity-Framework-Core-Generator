using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class MessageCenterUserAcknowledgement
    {
        public MessageCenterUserAcknowledgement()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long? MessageId { get; set; }

        public long? UserId { get; set; }

        public int? IsAcknowledged { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdateDate { get; set; }

        public string UpdateBy { get; set; }

        public int? Status { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
