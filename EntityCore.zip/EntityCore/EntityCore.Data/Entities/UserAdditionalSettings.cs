using System;
using System.Collections.Generic;

namespace EntityCore.Data.Entities
{
    public partial class UserAdditionalSettings
    {
        public UserAdditionalSettings()
        {
            #region Generated Constructor
            #endregion
        }

        #region Generated Properties
        public long Id { get; set; }

        public long UserId { get; set; }

        public decimal? StandardRateFileD { get; set; }

        public decimal? StandardRateFileE { get; set; }

        public int? StandardTimeFileD { get; set; }

        public int? StandardTimeFileE { get; set; }

        public decimal? BaseHouseSize { get; set; }

        public decimal? AdditionalAreaSize { get; set; }

        public decimal? AdditionalAreaRate { get; set; }

        public decimal? MaxTravelDistance { get; set; }

        public decimal? TravelRadius { get; set; }

        public decimal? AdditionalTravelDistance { get; set; }

        public decimal? AdditionalTravelRate { get; set; }

        public int Status { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        #endregion

        #region Generated Relationships
        #endregion

    }
}
